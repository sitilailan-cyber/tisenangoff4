import React from 'react';
import { Home, Compass, User } from 'lucide-react';

export type MuridTabType = 'beranda' | 'misi' | 'profil' | 'ai' | 'lab' | 'portofolio';

interface MuridBottomNavProps {
  activeTab: MuridTabType;
  onTabChange: (tab: MuridTabType) => void;
}

export const MuridBottomNav: React.FC<MuridBottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  // 3 Menu Utama di Header Bagian Bawah: Beranda (Pink), Misi (Kuning), Profil (Hijau)
  // Ukuran ditambah 20%, logo membesar dan bercahaya saat aktif
  const tabs = [
    {
      id: 'beranda' as MuridTabType,
      label: 'Beranda',
      icon: Home,
      inactiveIcon: 'text-pink-500 fill-pink-500/10',
      activeIcon: 'text-pink-500 fill-pink-500/35 drop-shadow-[0_0_12px_rgba(236,72,153,0.95)] scale-125 sm:scale-130 -translate-y-0.5',
      activeStyle: 'bg-pink-50/95 border-pink-300 ring-2 ring-pink-400/40 text-pink-700 shadow-[0_0_18px_rgba(244,114,182,0.35)]',
    },
    {
      id: 'misi' as MuridTabType,
      label: 'Misi',
      icon: Compass,
      inactiveIcon: 'text-amber-500 fill-amber-500/10',
      activeIcon: 'text-amber-500 fill-amber-500/35 drop-shadow-[0_0_12px_rgba(245,158,11,0.95)] scale-125 sm:scale-130 -translate-y-0.5',
      activeStyle: 'bg-amber-50/95 border-amber-300 ring-2 ring-amber-400/40 text-amber-800 shadow-[0_0_18px_rgba(251,191,36,0.35)]',
    },
    {
      id: 'profil' as MuridTabType,
      label: 'Profil',
      icon: User,
      inactiveIcon: 'text-emerald-500 fill-emerald-500/10',
      activeIcon: 'text-emerald-500 fill-emerald-500/35 drop-shadow-[0_0_12px_rgba(16,185,129,0.95)] scale-125 sm:scale-130 -translate-y-0.5',
      activeStyle: 'bg-emerald-50/95 border-emerald-300 ring-2 ring-emerald-400/40 text-emerald-800 shadow-[0_0_18px_rgba(52,211,153,0.35)]',
    },
  ];

  return (
    <footer
      id="murid-bottom-nav"
      style={{
        paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 10px)',
      }}
      className="w-full shrink-0 z-30 bg-white/98 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-3px_18px_rgba(0,0,0,0.04)] select-none"
    >
      <div className="w-full max-w-lg mx-auto px-4 py-2 sm:py-2.5 flex items-center justify-around gap-2.5 sm:gap-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive =
            activeTab === tab.id ||
            (tab.id === 'misi' && activeTab === 'lab') ||
            (tab.id === 'profil' && activeTab === 'portofolio');

          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 max-w-[145px] inline-flex items-center justify-center gap-2 py-2 sm:py-2.5 px-3.5 sm:px-4.5 rounded-2xl transition-all duration-300 cursor-pointer active:scale-95 group ${
                isActive
                  ? `${tab.activeStyle} font-black`
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70 border border-transparent font-bold'
              }`}
            >
              {/* Logo Menu: Membesar dan Bercahaya saat Aktif */}
              <Icon
                className={`w-5 h-5 shrink-0 stroke-[2.3] transition-all duration-300 ${
                  isActive ? tab.activeIcon : `${tab.inactiveIcon} group-hover:scale-110`
                }`}
              />

              {/* Label Menu (Ukuran bertambah 20%) */}
              <span
                className={`text-xs sm:text-[13px] leading-none tracking-tight transition-all duration-200 ${
                  isActive ? 'font-black scale-105' : 'font-bold'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </footer>
  );
};



