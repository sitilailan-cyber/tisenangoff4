import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  radius: number;
  speedY: number;
  swaySpeed: number;
  swayAmplitude: number;
  swayOffset: number;
  opacity: number;
  color: string;
}

export const AmbientScienceBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = 0;
    let height = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2); // Cap at 2 for mobile efficiency
      width = rect.width;
      height = rect.height;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener('resize', resize);

    // Particle colors: soft cyan, sky blue, soft indigo, gentle lavender
    const particleColors = [
      'rgba(56, 189, 248,',  // cyan-400
      'rgba(125, 211, 252,', // sky-300
      'rgba(165, 180, 252,', // indigo-300
      'rgba(244, 114, 182,', // pink-400
      'rgba(255, 255, 255,', // pure soft white
    ];

    // Controlled count: 24 particles is lightweight for mobile HP while giving alive ambient atmosphere
    const particleCount = 24;
    const particles: Particle[] = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * (width || 800),
        y: Math.random() * (height || 1000),
        radius: 0.8 + Math.random() * 1.5,
        speedY: 0.18 + Math.random() * 0.35, // Slow, peaceful upward drift
        swaySpeed: 0.008 + Math.random() * 0.015,
        swayAmplitude: 6 + Math.random() * 14,
        swayOffset: Math.random() * Math.PI * 2,
        opacity: 0.12 + Math.random() * 0.22,
        color: particleColors[Math.floor(Math.random() * particleColors.length)],
      });
    }

    let frameCount = 0;

    const render = () => {
      frameCount++;
      ctx.clearRect(0, 0, width, height);

      // Render drifting particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.y -= p.speedY;
        const currentX = p.x + Math.sin(frameCount * p.swaySpeed + p.swayOffset) * p.swayAmplitude;

        // Reset if drifted above the canvas
        if (p.y < -10) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }

        ctx.beginPath();
        ctx.arc(currentX, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color} ${p.opacity})`;
        ctx.shadowColor = `${p.color} 0.4)`;
        ctx.shadowBlur = 4;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none z-0">
      {/* 1. Luminous Micro-Particles Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
      />

      {/* 2. Undulating Ambient Science Waves (Harmonic & Standing Waves) */}
      <div className="absolute inset-0 overflow-hidden opacity-25 animate-wave-ambient pointer-events-none">
        <svg
          viewBox="0 0 1200 400"
          preserveAspectRatio="none"
          className="w-full h-full"
        >
          <defs>
            <linearGradient id="waveGradCyan" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.02" />
              <stop offset="35%" stopColor="#38bdf8" stopOpacity="0.28" />
              <stop offset="65%" stopColor="#818cf8" stopOpacity="0.32" />
              <stop offset="100%" stopColor="#c084fc" stopOpacity="0.02" />
            </linearGradient>
            <linearGradient id="waveGradIndigo" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#818cf8" stopOpacity="0.02" />
              <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.24" />
              <stop offset="100%" stopColor="#f472b6" stopOpacity="0.02" />
            </linearGradient>
          </defs>

          {/* Smooth harmonic sine wave */}
          <path
            d="M 0 160 C 260 250, 520 60, 800 170 C 980 230, 1100 120, 1200 150"
            fill="none"
            stroke="url(#waveGradCyan)"
            strokeWidth="1.6"
          />

          {/* Secondary phase interference wave (dashed) */}
          <path
            d="M 0 220 C 320 110, 640 280, 960 140 C 1080 90, 1150 190, 1200 170"
            fill="none"
            stroke="url(#waveGradIndigo)"
            strokeWidth="1.2"
            strokeDasharray="5 7"
          />

          {/* Deep harmonic baseline wave */}
          <path
            d="M 0 310 C 240 260, 560 360, 840 290 C 1020 245, 1140 330, 1200 300"
            fill="none"
            stroke="url(#waveGradCyan)"
            strokeWidth="1"
            strokeOpacity="0.6"
          />
        </svg>
      </div>

      {/* 3. Floating Geometric Mathematical & Science Elements */}
      {/* 3a. Hexagonal Molecular / Benzene Carbon Ring (Top-Right, Slow Spin) */}
      <div className="absolute -top-6 right-8 w-44 h-44 opacity-[0.11] pointer-events-none animate-spin-slow">
        <svg viewBox="0 0 100 100" className="w-full h-full text-cyan-400 stroke-current">
          <polygon
            points="50,5 90,27.5 90,72.5 50,95 10,72.5 10,27.5"
            fill="none"
            strokeWidth="1.2"
          />
          <polygon
            points="50,18 80,35 80,65 50,82 20,65 20,35"
            fill="none"
            strokeWidth="0.8"
            strokeDasharray="3 3"
          />
          {/* Hexagon vertices atom nodes */}
          <circle cx="50" cy="5" r="2.5" fill="currentColor" />
          <circle cx="90" cy="27.5" r="2.5" fill="currentColor" />
          <circle cx="90" cy="72.5" r="2.5" fill="currentColor" />
          <circle cx="50" cy="95" r="2.5" fill="currentColor" />
          <circle cx="10" cy="72.5" r="2.5" fill="currentColor" />
          <circle cx="10" cy="27.5" r="2.5" fill="currentColor" />
        </svg>
      </div>

      {/* 3b. Atomic Orbital Shell with Electron Dot (Center-Left, Reverse Slow Spin) */}
      <div className="absolute top-1/3 -left-8 w-52 h-52 opacity-[0.09] pointer-events-none animate-spin-reverse-slow">
        <svg viewBox="0 0 100 100" className="w-full h-full text-indigo-400 stroke-current">
          <ellipse cx="50" cy="50" rx="44" ry="18" fill="none" strokeWidth="1" transform="rotate(-30 50 50)" />
          <ellipse cx="50" cy="50" rx="44" ry="18" fill="none" strokeWidth="1" transform="rotate(30 50 50)" />
          <circle cx="50" cy="50" r="3.5" fill="currentColor" />
          <circle cx="86" cy="38" r="2" fill="currentColor" />
          <circle cx="16" cy="62" r="2" fill="currentColor" />
        </svg>
      </div>

      {/* 3c. Cartesian Coordinate Crosshair with Unit Tick Marks (Bottom-Right, Subtle Drift) */}
      <div className="absolute bottom-16 right-12 w-36 h-36 opacity-[0.09] pointer-events-none animate-subtle-drift">
        <svg viewBox="0 0 100 100" className="w-full h-full text-sky-400 stroke-current">
          {/* Axis X and Y */}
          <line x1="5" y1="50" x2="95" y2="50" strokeWidth="1.2" />
          <line x1="50" y1="5" x2="50" y2="95" strokeWidth="1.2" />
          {/* Arrows */}
          <polyline points="90,46 95,50 90,54" fill="none" strokeWidth="1.2" />
          <polyline points="46,10 50,5 54,10" fill="none" strokeWidth="1.2" />
          {/* Coordinate Ticks */}
          <line x1="30" y1="47" x2="30" y2="53" strokeWidth="1" />
          <line x1="70" y1="47" x2="70" y2="53" strokeWidth="1" />
          <line x1="47" y1="30" x2="53" y2="30" strokeWidth="1" />
          <line x1="47" y1="70" x2="53" y2="70" strokeWidth="1" />
          {/* Linear regression line sample */}
          <line x1="18" y1="78" x2="82" y2="22" strokeWidth="1" strokeDasharray="2 3" opacity="0.8" />
        </svg>
      </div>

      {/* 3d. Subtle Mathematical Integral & Greek Symbols (Top-Center, Floating) */}
      <div className="absolute top-20 left-1/4 opacity-[0.07] pointer-events-none font-serif text-3xl text-cyan-200 select-none animate-subtle-float">
        ∫
      </div>
      <div className="absolute top-48 right-1/4 opacity-[0.07] pointer-events-none font-serif text-2xl text-purple-200 select-none animate-subtle-drift">
        Σ
      </div>
      <div className="absolute bottom-32 left-1/5 opacity-[0.06] pointer-events-none font-mono text-xl text-sky-200 select-none animate-subtle-float">
        Δy/Δx
      </div>
      <div className="absolute bottom-40 right-1/3 opacity-[0.06] pointer-events-none font-serif text-2xl text-indigo-200 select-none animate-subtle-drift">
        λ
      </div>

      {/* 4. Ambient Radial Glow Vignette (Deep, Warm & Premium) */}
      <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-cyan-500/10 blur-[90px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-96 h-96 rounded-full bg-indigo-600/10 blur-[100px] pointer-events-none" />
    </div>
  );
};
