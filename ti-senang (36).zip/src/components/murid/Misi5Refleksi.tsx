import React, { useState } from 'react';
import {
  Brain,
  Star,
  CheckCircle2,
  ArrowRight,
  Send,
  Sparkles,
  HelpCircle,
  FileText,
  FileDown,
  AlertCircle,
  Award,
} from 'lucide-react';
import { Mission, StudentReflectionSubmission } from '../../types';
import { storage } from '../../services/storage';
import { exportRefleksiToPdf } from '../../utils/pdfExport';
import { exportRefleksiToExcel } from '../../utils/excelExport';
import { ExportDropdown } from '../common/ExportDropdown';

interface Misi5RefleksiProps {
  studentId: string;
  studentName?: string;
  classId?: string;
  className?: string;
  missionId: string;
  mission?: Mission;
  onCompleted?: () => void;
  onNextMission?: (nextMissionNumber: number) => void;
  onClose?: () => void;
}

export const Misi5Refleksi: React.FC<Misi5RefleksiProps> = ({
  studentId,
  studentName = 'Murid TI SENANG',
  classId = 'cls-xii-1',
  className = 'XII-1',
  missionId,
  mission,
  onCompleted,
  onNextMission,
  onClose,
}) => {
  // Existing submission if any
  const existingSubmissions = storage.getStudentReflections(classId, studentId);
  const existing = existingSubmissions.find((r) => r.missionId === missionId);

  // 1. REFLEKSI PEMBELAJARAN (4 Pertanyaan Mendalam)
  const [konsepBermakna, setKonsepBermakna] = useState<string>(
    existing?.refleksiAnswers?.[0] || '',
  );
  const [kendalaDanSolusi, setKendalaDanSolusi] = useState<string>(
    existing?.refleksiAnswers?.[1] || '',
  );
  const [relevansiNyata, setRelevansiNyata] = useState<string>(
    existing?.refleksiAnswers?.[2] || '',
  );
  const [rencanaPerbaikan, setRencanaPerbaikan] = useState<string>(
    existing?.refleksiAnswers?.[3] || '',
  );

  // 2. PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT: 1 - 4 Stars)
  const [kemandirian, setKemandirian] = useState<number>(
    existing?.selfAssessment?.kemandirian || 3,
  );
  const [pemahamanKonsep, setPemahamanKonsep] = useState<number>(
    existing?.selfAssessment?.pemahamanKonsep || 3,
  );
  const [keterampilanData, setKeterampilanData] = useState<number>(
    existing?.selfAssessment?.keterampilanData || 3,
  );
  const [sikapKritis, setSikapKritis] = useState<number>(
    existing?.selfAssessment?.sikapKritis || 4,
  );
  const [komitmenDiri, setKomitmenDiri] = useState<string>(
    existing?.selfAssessment?.komitmenDiri || '',
  );

  const [isSubmitted, setIsSubmitted] = useState<boolean>(!!existing);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Hitung rata-rata skor penilaian diri (%)
  const selfScoreAverage =
    Math.round(((kemandirian + pemahamanKonsep + keterampilanData + sikapKritis) / 16) * 100);

  const handleSaveAndSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!konsepBermakna.trim() || !kendalaDanSolusi.trim()) {
      alert('Mohon isi minimal pertanyaan 1 (Konsep Bermakna) dan 2 (Kendala & Solusi) sebelum mengirim refleksi.');
      return;
    }

    setIsSubmitting(true);

    const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
    const submission: StudentReflectionSubmission = {
      id: existing?.id || `refl-${Date.now()}`,
      studentId,
      studentName: cleanStudentName,
      classId,
      className,
      missionId,
      missionTitle: mission?.title || 'Refleksi & Penilaian Diri',
      submittedAt: new Date().toISOString(),
      reflectionAnswers: {
        pemahaman: konsepBermakna.trim(),
        tantangan: kendalaDanSolusi.trim(),
        halMenarik: relevansiNyata.trim(),
        rencanaPerbaikan: rencanaPerbaikan.trim(),
      },
      refleksiAnswers: [
        konsepBermakna.trim(),
        kendalaDanSolusi.trim(),
        relevansiNyata.trim() || 'Memahami penerapan sains dalam fenomena alam sehari-hari.',
        rencanaPerbaikan.trim() || 'Terus berlatih menganalisis data dan berpikir kritis.',
      ],
      selfAssessment: {
        kemandirian,
        pemahamanKonsep,
        keterampilanAnalisis: keterampilanData,
        sikapReflektif: sikapKritis,
        keterampilanData,
        sikapKritis,
        totalScorePercentage: selfScoreAverage,
        komitmen: komitmenDiri.trim() || 'Berkomitmen untuk terus belajar mandiri dan berintegritas.',
        komitmenDiri: komitmenDiri.trim() || 'Berkomitmen untuk terus belajar mandiri dan berintegritas.',
      },
      averageSelfScore: selfScoreAverage,
      teacherFeedback: existing?.teacherFeedback || '',
    };

    // 1. Simpan ke database storage (sync Firebase RTDB)
    storage.saveStudentReflection(submission);

    // 2. Selesaikan Misi 5 (TIDAK ADA PORTOFOLIO)
    storage.completeMission(studentId, missionId, selfScoreAverage, mission?.xpReward || 110);

    setIsSubmitting(false);
    setIsSubmitted(true);

    // 3. Callback membuka Misi 6 otomatis
    if (onCompleted) {
      onCompleted();
    }
  };

  const handleDownloadPdf = () => {
    const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
    const currentSub: StudentReflectionSubmission = {
      id: existing?.id || `refl-${Date.now()}`,
      studentId,
      studentName: cleanStudentName,
      classId,
      className,
      subjectName: mission?.subjectName || 'Fisika & Literasi Sains',
      missionId,
      missionTitle: mission?.title || 'Refleksi Pembelajaran & Penilaian Diri',
      submittedAt: existing?.submittedAt || new Date().toISOString(),
      reflectionAnswers: {
        pemahaman: konsepBermakna.trim() || 'Murid telah memahami konsep materi dan penerapannya dengan baik.',
        tantangan: kendalaDanSolusi.trim() || 'Dapat diselesaikan secara mandiri dan diskusi bersama rekan.',
        halMenarik: relevansiNyata.trim() || 'Simulasi virtual lab dan analisis data regresi linear sangat membantu pemahaman.',
        rencanaPerbaikan: rencanaPerbaikan.trim() || 'Meningkatkan ketelitian analisis data dan berlatih penalaran soal.',
      },
      refleksiAnswers: [
        konsepBermakna.trim() || 'Konsep sains dan prinsip fisis dipahami secara mendalam.',
        kendalaDanSolusi.trim() || 'Kendala analisis dapat diatasi melalui bimbingan guru dan eksperimen mandiri.',
        relevansiNyata.trim() || 'Simulasi praktikum dan grafik mempermudah pemahaman.',
        rencanaPerbaikan.trim() || 'Terus berlatih berpikir kritis dan merumuskan hipotesis ilmiah.',
      ],
      selfAssessment: {
        kemandirian,
        pemahamanKonsep,
        keterampilanAnalisis: keterampilanData,
        sikapReflektif: sikapKritis,
        keterampilanData,
        sikapKritis,
        totalScorePercentage: selfScoreAverage,
        komitmen: komitmenDiri.trim() || 'Berkomitmen untuk terus belajar mandiri dan berintegritas.',
        komitmenDiri: komitmenDiri.trim() || 'Berkomitmen untuk terus belajar mandiri dan berintegritas.',
      },
      averageSelfScore: selfScoreAverage,
    };
    exportRefleksiToPdf(currentSub);
  };

  const handleDownloadExcel = () => {
    const currentSub: StudentReflectionSubmission = {
      id: existing?.id || `refl-${Date.now()}`,
      studentId,
      studentName,
      classId,
      className,
      subjectName: 'Fisika & Literasi Sains',
      missionId,
      missionTitle: mission?.title || 'Refleksi & Penilaian Diri',
      submittedAt: new Date().toISOString(),
      reflectionAnswers: {
        pemahaman: konsepBermakna.trim(),
        tantangan: kendalaDanSolusi.trim(),
        halMenarik: relevansiNyata.trim(),
        rencanaPerbaikan: rencanaPerbaikan.trim(),
      },
      refleksiAnswers: [
        konsepBermakna.trim(),
        kendalaDanSolusi.trim(),
        relevansiNyata.trim(),
        rencanaPerbaikan.trim(),
      ],
      selfAssessment: {
        kemandirian,
        pemahamanKonsep,
        keterampilanAnalisis: keterampilanData,
        sikapReflektif: sikapKritis,
        keterampilanData,
        sikapKritis,
        totalScorePercentage: selfScoreAverage,
        komitmen: komitmenDiri.trim(),
        komitmenDiri: komitmenDiri.trim(),
      },
      averageSelfScore: selfScoreAverage,
    };
    exportRefleksiToExcel(currentSub);
  };

  const renderRatingStars = (
    value: number,
    onChange: (val: number) => void,
    label: string,
    descList: [string, string, string, string],
  ) => {
    return (
      <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <label className="text-xs font-bold text-slate-800">{label}</label>
          <span className="text-[11px] font-semibold text-indigo-600">
            {descList[value - 1]}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4].map((star) => (
            <button
              key={star}
              type="button"
              disabled={isSubmitted}
              onClick={() => onChange(star)}
              className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                star <= value
                  ? 'text-amber-500 hover:scale-110'
                  : 'text-slate-300 hover:text-amber-300'
              }`}
            >
              <Star
                className="w-5 h-5"
                fill={star <= value ? 'currentColor' : 'none'}
              />
            </button>
          ))}
          <span className="text-xs font-mono font-bold text-slate-500 ml-1">
            {value} / 4
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-blue-700 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider mb-2">
              <Brain className="w-3.5 h-3.5" />
              Misi 5 • Refleksi Pembelajaran
            </div>
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold tracking-tight">
              Refleksi Pembelajaran & Penilaian Diri
            </h1>
            <p className="text-purple-100 text-xs sm:text-sm mt-1 max-w-xl">
              Tuliskan refleksi pengalaman belajar sains Anda dan lakukan penilaian diri mandiri. Hasil otomatis dikirim ke guru dan membuka Misi 6!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
            <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur border border-white/30 text-white">
              +{mission?.xpReward || 110} XP
            </span>
            {isSubmitted && (
              <ExportDropdown
                onExportPdf={handleDownloadPdf}
                onExportExcel={handleDownloadExcel}
                label="Unduh Refleksi"
                theme="light"
              />
            )}
          </div>
        </div>
      </div>

      {/* SUCCESS CONFIRMATION IF SUBMITTED */}
      {isSubmitted && (
        <div className="p-5 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 rounded-3xl text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6 text-purple-200" />
            </div>
            <div>
              <h3 className="text-base font-bold">Refleksi Berhasil Dikirim ke Guru!</h3>
              <p className="text-xs text-purple-100 mt-0.5">
                Skor Penilaian Diri: <strong>{selfScoreAverage}%</strong>. Hasil refleksi telah masuk ke dashboard guru dan Misi 6 (Asesmen) telah terbuka!
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <ExportDropdown
              onExportPdf={handleDownloadPdf}
              onExportExcel={handleDownloadExcel}
              label="Unduh Refleksi"
              theme="dark"
            />
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-white text-purple-900 hover:bg-purple-50 text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
              >
                <span>Tutup & Lanjut Misi 6</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}

      <form onSubmit={handleSaveAndSubmit} className="space-y-6">
        {/* BAGIAN 1: REFLEKSI PEMBELAJARAN */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
            <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display font-bold text-slate-800 text-base">
                1. Refleksi Pembelajaran Saintifik
              </h2>
              <p className="text-xs text-slate-500">
                Jawablah pertanyaan reflektif di bawah secara jujur, mendalam, dan berbasis pengalaman belajarmu.
              </p>
            </div>
          </div>

          {/* Pertanyaan 1 */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span>a. Konsep sains apa yang paling Anda pahami dengan jelas dan bermakna?</span>
              <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              disabled={isSubmitted}
              value={konsepBermakna}
              onChange={(e) => setKonsepBermakna(e.target.value)}
              placeholder="Contoh: Saya paling memahami bagaimana model regresi linier y = mx + c dapat merefleksikan laju penyerapan kalor pada bejana air, di mana gradien m adalah laju kenaikan suhu per menit..."
              className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
            />
          </div>

          {/* Pertanyaan 2 */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span>b. Apa kendala terbesar yang Anda hadapi dan bagaimana Anda mengatasinya?</span>
              <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={3}
              disabled={isSubmitted}
              value={kendalaDanSolusi}
              onChange={(e) => setKendalaDanSolusi(e.target.value)}
              placeholder="Contoh: Awalnya saya sempat bingung menentukan makna fisis R², namun setelah melihat grafik simulasi dan membaca materi guru, saya mengerti bahwa R² mengukur seberapa baik garis merefleksikan data..."
              className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
            />
          </div>

          {/* Pertanyaan 3 */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800">
              c. Bagaimana keterkaitan konsep sains ini dengan fenomena nyata sehari-hari?
            </label>
            <textarea
              rows={2}
              disabled={isSubmitted}
              value={relevansiNyata}
              onChange={(e) => setRelevansiNyata(e.target.value)}
              placeholder="Contoh: Sangat relevan saat kita merebus air atau memilih material pakaian/insulator termos agar menahan panas..."
              className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
            />
          </div>

          {/* Pertanyaan 4 */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800">
              d. Apa rencana aksi/perbaikan diri Anda untuk materi pembelajaran berikutnya?
            </label>
            <textarea
              rows={2}
              disabled={isSubmitted}
              value={rencanaPerbaikan}
              onChange={(e) => setRencanaPerbaikan(e.target.value)}
              placeholder="Contoh: Saya akan lebih teliti dalam mencatat satuan ukur dan memperdalam interpretasi statistik korelasi..."
              className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
            />
          </div>
        </div>

        {/* BAGIAN 2: PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                <Star className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-display font-bold text-slate-800 text-base">
                  2. Rubrik Penilaian Diri Sendiri (Self-Assessment)
                </h2>
                <p className="text-xs text-slate-500">
                  Nilai capaian diri Anda secara jujur menggunakan rubrik skala 1 sampai 4 bintang di bawah.
                </p>
              </div>
            </div>

            <span className="px-3 py-1 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 text-xs font-bold font-mono self-start sm:self-auto">
              Skor Mandiri: {selfScoreAverage}%
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {renderRatingStars(
              kemandirian,
              setKemandirian,
              '1. Kemandirian & Keaktifan Belajar',
              ['Perlu Bimbingan', 'Cukup Mandiri', 'Mandiri & Aktif', 'Sangat Mandiri & Inisiatif'],
            )}

            {renderRatingStars(
              pemahamanKonsep,
              setPemahamanKonsep,
              '2. Pemahaman Konsep & Penalaran Ilmiah',
              ['Perlu Penguatan', 'Cukup Paham', 'Paham & Bernalar Baik', 'Sangat Menguasai Konsep'],
            )}

            {renderRatingStars(
              keterampilanData,
              setKeterampilanData,
              '3. Keterampilan Pengolahan Data & Grafik',
              ['Perlu Bantuan', 'Cukup Terampil', 'Terampil & Presisi', 'Sangat Mahir Mengolah Data'],
            )}

            {renderRatingStars(
              sikapKritis,
              setSikapKritis,
              '4. Sikap Kritis, Teliti & Bertanggung Jawab',
              ['Kurang Teliti', 'Cukup Kritis', 'Kritis & Bertanggung Jawab', 'Sangat Kritis & Berintegritas'],
            )}
          </div>

          {/* Komitmen Peningkatan Diri */}
          <div className="space-y-1.5 pt-2">
            <label className="text-xs font-bold text-slate-800">
              Komitmen Pribadi Peningkatan Belajar:
            </label>
            <input
              type="text"
              disabled={isSubmitted}
              value={komitmenDiri}
              onChange={(e) => setKomitmenDiri(e.target.value)}
              placeholder="Contoh: Saya berkomitmen untuk senantiasa disiplin waktu dan berani bertanya saat menjumpai kendala..."
              className="w-full h-10 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-400 disabled:bg-slate-50"
            />
          </div>
        </div>

        {/* FOOTER: 2 TOMBOL UTAMA - SIMPAN PDF & KIRIM REFLEKSI */}
        <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          <div className="text-xs text-slate-600 space-y-0.5 max-w-lg">
            <p className="font-bold text-slate-800 text-xs sm:text-sm">Dokumen & Pengiriman Refleksi Pembelajaran</p>
            <p className="text-slate-500 text-[11px] sm:text-xs">
              Klik <strong>"Simpan PDF"</strong> untuk mengunduh dokumen refleksi (nama & kelas otomatis tercantum). Klik <strong>"Kirim Refleksi"</strong> untuk mengirim ke Dashboard Guru dan membuka Misi 6!
            </p>
          </div>

          <div className="w-full md:w-auto shrink-0 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            {/* Tombol 1: Simpan PDF */}
            <button
              id="btn-simpan-pdf-refleksi"
              type="button"
              onClick={handleDownloadPdf}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-emerald-600 hover:bg-emerald-700 text-white text-center leading-snug whitespace-nowrap"
            >
              <FileDown className="w-4 h-4 shrink-0 text-emerald-100" />
              <span>Simpan PDF</span>
            </button>

            {/* Tombol 2: Kirim Refleksi */}
            <button
              id="btn-kirim-refleksi"
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white text-center leading-snug whitespace-nowrap"
            >
              {isSubmitted ? (
                <>
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-300" />
                  <span>Kirim Refleksi (Perbarui)</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 shrink-0" />
                  <span>Kirim Refleksi</span>
                </>
              )}
            </button>

            {isSubmitted && (
              <button
                id="btn-terkirim-lanjut-misi-6"
                type="button"
                onClick={() => {
                  if (onNextMission) {
                    onNextMission(6);
                  } else if (onClose) {
                    onClose();
                  }
                }}
                className="w-full sm:w-auto px-4 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-slate-900 hover:bg-slate-800 text-white text-center leading-snug whitespace-nowrap"
              >
                <span>Lanjut ke Misi 6</span>
                <ArrowRight className="w-4 h-4 shrink-0 text-purple-200" />
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};
