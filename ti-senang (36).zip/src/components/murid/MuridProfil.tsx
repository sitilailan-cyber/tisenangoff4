import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  User,
  Users,
  Star,
  Award,
  ShieldCheck,
  Flame,
  LogOut,
  FolderOpen,
  Calendar,
  Sparkles,
  Eye,
  CheckCircle2,
  BookOpen,
  Camera,
  Trash2,
  TrendingUp,
  TrendingDown,
  Atom,
  Binary,
  FlaskConical,
  Upload,
  RefreshCw,
  X,
  Check,
  ChevronDown,
  ChevronUp,
  FileText,
  FileUp,
  Cpu,
  UserCheck,
} from 'lucide-react';
import { StudentProfileData, PortfolioItem, StudentProgress, PortfolioCategory, Student } from '../../types';
import { storage } from '../../services/storage';
import { useAuth } from '../../context/AuthContext';
import { Modal } from '../common/Modal';
import { UploadPortfolioModal } from './UploadPortfolioModal';
import { STUDENT_AVATAR_OPTIONS } from '../../constants/studentAvatars';

import studentCalorimeterPhoto from '../../assets/images/student_physics_calorimeter_1789115270932.jpg';
import studentRegressionPhoto from '../../assets/images/student_data_regression_1789115288218.jpg';
import studentChemPhoto from '../../assets/images/student_chem_experiment_1789115301650.jpg';
import studentBioPhoto from '../../assets/images/student_bio_project_1789115315113.jpg';

interface MuridProfilProps {
  profile: StudentProfileData;
  portfolios: PortfolioItem[];
  progressList: StudentProgress[];
  onRefreshPortfolios: () => void;
  onLogout: () => void;
  onNavigateToLab?: () => void;
}

// Pilihan avatar resmi murid
const PRESET_AVATARS = STUDENT_AVATAR_OPTIONS;

interface WeeklySubjectReport {
  id: string;
  subject: string;
  topic: string;
  trend: 'MENINGKAT' | 'MENURUN';
  percentage: string;
  icon: typeof Atom;
  competency: string;
  description: string;
  recommendation: string;
}

export const MuridProfil: React.FC<MuridProfilProps> = ({
  profile,
  portfolios,
  progressList,
  onRefreshPortfolios,
  onLogout,
  onNavigateToLab,
}) => {
  const { updateCurrentUser } = useAuth();
  const [selectedPortfolio, setSelectedPortfolio] = useState<PortfolioItem | null>(null);
  const [showEditPhotoModal, setShowEditPhotoModal] = useState(false);
  const [previewAvatar, setPreviewAvatar] = useState<string>('');
  const [photoSaveMessage, setPhotoSaveMessage] = useState<string | null>(null);

  // State untuk Laporan Mingguan (Buka/Tutup Deskripsi per Pelajaran)
  const [openReportId, setOpenReportId] = useState<string | null>(null);

  // State untuk Upload Portofolio Baru
  const [showUploadPortfolioModal, setShowUploadPortfolioModal] = useState(false);
  const [portfolioForm, setPortfolioForm] = useState({
    title: '',
    subjectName: 'Fisika',
    category: 'Eksperimen' as PortfolioCategory,
    reflectionSummary: '',
    conclusion: '',
  });
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    size: number;
    dataUrl?: string;
  } | null>(null);
  const [isDraggingFile, setIsDraggingFile] = useState(false);
  const [uploadSuccessMsg, setUploadSuccessMsg] = useState<string | null>(null);
  const portfolioFileInputRef = useRef<HTMLInputElement>(null);

  const completedCount = progressList.filter((p) => p.status === 'COMPLETED').length;
  
  // Real-time synchronization state for profile & students
  const [profileState, setProfileState] = useState<StudentProfileData>(profile);
  const studentClassId = profileState.student?.classId || profile.student?.classId || '';
  const [classStudentsList, setClassStudentsList] = useState<Student[]>(() => {
    return studentClassId ? storage.getStudentsByClass(studentClassId) : [];
  });

  useEffect(() => {
    setProfileState(profile);
    if (profile.student?.classId) {
      setClassStudentsList(storage.getStudentsByClass(profile.student.classId));
    }
  }, [profile]);

  useEffect(() => {
    const handleKelompokSync = () => {
      const refreshed = storage.getStudentProfile(profile.user.id);
      if (refreshed) {
        setProfileState(refreshed);
        if (refreshed.student?.classId) {
          setClassStudentsList(storage.getStudentsByClass(refreshed.student.classId));
        }
      }
    };
    window.addEventListener('tisenang_student_kelompok_updated', handleKelompokSync);
    window.addEventListener('tisenang_students_updated', handleKelompokSync);
    return () => {
      window.removeEventListener('tisenang_student_kelompok_updated', handleKelompokSync);
      window.removeEventListener('tisenang_students_updated', handleKelompokSync);
    };
  }, [profile.user.id]);

  const user = profileState.user;
  const studentId = profileState.student?.id || '';
  const currentStudent = profileState.student;
  const studentKelompok = currentStudent?.kelompok || 'Kelompok 1';

  const teammates = useMemo(() => {
    if (!studentKelompok || classStudentsList.length === 0) return [];
    return classStudentsList.filter(
      (s) => (s.kelompok || 'Kelompok 1') === studentKelompok && s.id !== studentId
    );
  }, [studentKelompok, classStudentsList, studentId]);

  // Data Asli Laporan Perkembangan Mingguan Berdasarkan Aktivitas Real Siswa
  const weeklyProgressData = useMemo<WeeklySubjectReport[]>(() => {
    const reports: WeeklySubjectReport[] = [];

    // 1. Capaian Misi Pembelajaran Sains & Fisika (MIPA)
    const completedProgress = (progressList || []).filter((p) => p.status === 'COMPLETED');
    const completedMissionsCount = completedProgress.length;
    const avgScore =
      completedMissionsCount > 0
        ? Math.round(
            completedProgress.reduce((sum, p) => sum + (p.score || 80), 0) / completedMissionsCount,
          )
        : 0;

    if (completedMissionsCount > 0) {
      reports.push({
        id: 'real-prog-misi',
        subject: 'Fisika & Sains MIPA',
        topic: `Tuntas ${completedMissionsCount} dari 6 Misi Pembelajaran`,
        trend: avgScore >= 75 ? 'MENINGKAT' : 'MENURUN',
        percentage: `+${Math.min(100, Math.round((completedMissionsCount / 6) * 100))}%`,
        icon: Atom,
        competency: `Penyelesaian Misi Pembelajaran Berbasis Inquiry (${completedMissionsCount}/6 Tuntas)`,
        description: `Murid telah menuntaskan ${completedMissionsCount} dari 6 misi pembelajaran kurikulum Fase F dengan capaian rata-rata skor ${avgScore}/100. Bukti pengerjaan misi tercatat aktif di basis data.`,
        recommendation:
          completedMissionsCount === 6
            ? 'Seluruh 6 misi pembelajaran telah selesai dengan gemilang! Pertahankan ketekunan belajar sains.'
            : `Lanjutkan ke Misi ${completedMissionsCount + 1} untuk menyelesaikan seluruh tahapan pembelajaran Fase F.`,
      });
    }

    // 2. Portofolio Eksperimen Laboratorium & Virtual Lab
    const myPortfolios = (portfolios || []).filter((p) => p.studentId === studentId);
    if (myPortfolios.length > 0) {
      reports.push({
        id: 'real-prog-portofolio',
        subject: 'Eksperimen & Virtual Lab',
        topic: `${myPortfolios.length} Karya Portofolio Disimpan`,
        trend: 'MENINGKAT',
        percentage: `+${Math.min(100, myPortfolios.length * 25)}%`,
        icon: FlaskConical,
        competency: 'Investigasi Saintifik, Pengambilan Data Sensor & Portofolio Digital',
        description: `Telah mendokumentasikan ${myPortfolios.length} karya/eksperimen: ${myPortfolios
          .map((p) => p.title)
          .slice(0, 2)
          .join(', ')}. Seluruh data tersimpan permanen di database.`,
        recommendation:
          'Kemampuan analisis praktikum dan pengolahan data riil sangat baik. Terus tingkatkan variasi eksplorasi sensor.',
      });
    }

    // 3. Asesmen Diagnostik Awal & Sumatif Akhir Siswa
    const asesmenAkhirRecords = storage.getAsesmenAkhirRecords();
    const myAsesmenAkhir = asesmenAkhirRecords.find((a) => a.studentId === studentId);

    const asesmenAwalList = storage.getAsesmenAwal(studentClassId);
    const myAsesmenAwal = asesmenAwalList.find((a) => a.studentId === studentId);

    if (myAsesmenAkhir) {
      reports.push({
        id: 'real-prog-asesmen-akhir',
        subject: 'Asesmen Akhir Sumatif',
        topic: `Evaluasi Sumatif: Nilai ${myAsesmenAkhir.score}/100`,
        trend: myAsesmenAkhir.score >= 75 ? 'MENINGKAT' : 'MENURUN',
        percentage: `${myAsesmenAkhir.score >= 75 ? '+' : ''}${myAsesmenAkhir.score - 75}%`,
        icon: Binary,
        competency: `Ketercapaian TP Sumatif: ${myAsesmenAkhir.kktpStatus || (myAsesmenAkhir.score >= 75 ? 'Tuntas' : 'Belum Tuntas')} (Predikat ${myAsesmenAkhir.predikat || 'Baik'})`,
        description: `Telah menyelesaikan Asesmen Akhir Misi 6 dengan skor ${myAsesmenAkhir.score}/100. Rekaman capaian TP tersimpan di database guru.`,
        recommendation:
          myAsesmenAkhir.catatan ||
          'Kompetensi esensial telah terpenuhi sesuai kriteria ketercapaian tujuan pembelajaran.',
      });
    } else if (myAsesmenAwal) {
      const isSiap = myAsesmenAwal.readinessLevel === 'Siap Mandiri';
      reports.push({
        id: 'real-prog-asesmen-awal',
        subject: 'Asesmen Awal Diagnostik',
        topic: `Kesiapan Belajar: ${myAsesmenAwal.readinessLevel}`,
        trend: isSiap ? 'MENINGKAT' : 'MENURUN',
        percentage: `Skor ${myAsesmenAwal.diagnosticScore}`,
        icon: Binary,
        competency: `Literasi: ${myAsesmenAwal.literacyScore} • Numerasi: ${myAsesmenAwal.numeracyScore} • Penalaran: ${myAsesmenAwal.reasoningScore}`,
        description: `Hasil asesmen awal terdaftar di sistem dengan skor ${myAsesmenAwal.diagnosticScore}/100. Rekomendasi jalur adaptif ALME telah dikalibrasi sesuai kesiapan belajar murid.`,
        recommendation:
          myAsesmenAwal.notes ||
          'Pahami materi konsep awal dan selesaikan misi terpandu untuk mencapai level kesiapan mandiri penuh.',
      });
    }

    return reports;
  }, [profile, portfolios, progressList, studentId, studentClassId]);

  const handleDeletePortfolio = (id: string) => {
    if (window.confirm('Hapus karya portofolio ini?')) {
      storage.deletePortfolio(id);
      onRefreshPortfolios();
      setSelectedPortfolio(null);
    }
  };

  const handleOpenPhotoModal = () => {
    setPreviewAvatar(user.avatarUrl || STUDENT_AVATAR_OPTIONS[0].url);
    setPhotoSaveMessage(null);
    setShowEditPhotoModal(true);
  };

  const handleSaveAvatar = () => {
    if (!previewAvatar) return;
    storage.updateUser(user.id, { avatarUrl: previewAvatar });
    updateCurrentUser({ avatarUrl: previewAvatar });
    onRefreshPortfolios();
    setPhotoSaveMessage('Avatar profil berhasil diperbarui!');
    setTimeout(() => {
      setShowEditPhotoModal(false);
      setPhotoSaveMessage(null);
    }, 1200);
  };

  const handleResetAvatar = () => {
    storage.updateUser(user.id, { avatarUrl: undefined });
    updateCurrentUser({ avatarUrl: undefined });
    setPreviewAvatar('');
    onRefreshPortfolios();
    setPhotoSaveMessage('Avatar profil diatur ulang ke inisial nama.');
    setTimeout(() => {
      setShowEditPhotoModal(false);
      setPhotoSaveMessage(null);
    }, 1200);
  };

  // Handler Berkas Portofolio (Drag & Drop + Manual Selection)
  const processPortfolioFile = (file: File) => {
    if (file.size > 8 * 1024 * 1024) {
      alert('Ukuran file maksimal 8MB.');
      return;
    }

    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedFile({
          name: file.name,
          size: file.size,
          dataUrl: event.target?.result as string,
        });
      };
      reader.readAsDataURL(file);
    } else {
      setUploadedFile({
        name: file.name,
        size: file.size,
        dataUrl: undefined,
      });
    }
  };

  const handlePortfolioFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processPortfolioFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingFile(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDraggingFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processPortfolioFile(file);
    }
  };

  const handleSavePortfolioSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!portfolioForm.title.trim() || !portfolioForm.reflectionSummary.trim()) {
      alert('Mohon isi Judul Portofolio dan Deskripsi / Refleksi karya.');
      return;
    }

    const newPortfolio: PortfolioItem = {
      id: `pf-${Date.now()}`,
      studentId: user.id,
      studentName: user.fullName || user.username,
      classId: user.classId || 'fase-f-1',
      className: user.className || 'Kelas XI MIPA 1',
      title: portfolioForm.title.trim(),
      subjectName: portfolioForm.subjectName,
      date: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }),
      category: portfolioForm.category,
      xpEarned: 50,
      visibility: 'CLASS',
      reflectionSummary: portfolioForm.reflectionSummary.trim(),
      conclusion: portfolioForm.conclusion.trim() || undefined,
      documentation: uploadedFile?.dataUrl || (uploadedFile ? uploadedFile.name : undefined),
    };

    storage.savePortfolio(newPortfolio);
    onRefreshPortfolios();
    setUploadSuccessMsg('Portofolio berhasil diunggah (+50 XP)!');
    setTimeout(() => {
      setShowUploadPortfolioModal(false);
      setUploadSuccessMsg(null);
      setPortfolioForm({
        title: '',
        subjectName: 'Fisika',
        category: 'Eksperimen',
        reflectionSummary: '',
        conclusion: '',
      });
      setUploadedFile(null);
    }, 1200);
  };

  // Helper to obtain portfolio preview thumbnail (prioritizes authentic lab photo)
  const getPortfolioThumbnail = (item: PortfolioItem): string | null => {
    if (
      item.documentation &&
      item.documentation.trim() !== '' &&
      !item.documentation.includes('misi_') &&
      !item.documentation.includes('logo')
    ) {
      if (
        item.documentation.startsWith('data:image') ||
        item.documentation.startsWith('http') ||
        item.documentation.startsWith('/assets')
      ) {
        return item.documentation;
      }
    }

    const title = (item.title || '').toLowerCase();
    const subject = (item.subjectName || '').toLowerCase();

    if (
      title.includes('regresi') ||
      title.includes('matematika') ||
      title.includes('grafik') ||
      title.includes('bivariat') ||
      subject.includes('matematika')
    ) {
      return studentRegressionPhoto;
    }
    if (
      title.includes('kimia') ||
      title.includes('reaksi') ||
      title.includes('termokimia') ||
      title.includes('larutan') ||
      subject.includes('kimia')
    ) {
      return studentChemPhoto;
    }
    if (
      title.includes('biologi') ||
      title.includes('daun') ||
      title.includes('stomata') ||
      title.includes('transpirasi') ||
      title.includes('tanaman') ||
      subject.includes('biologi')
    ) {
      return studentBioPhoto;
    }
    if (
      title.includes('kalorimeter') ||
      title.includes('radiasi') ||
      title.includes('suhu') ||
      title.includes('kalor') ||
      subject.includes('fisika')
    ) {
      return studentCalorimeterPhoto;
    }

    return studentCalorimeterPhoto;
  };

  return (
    <div className="relative space-y-6 max-w-5xl mx-auto pb-12">
      {/* Ambient background glow layers (soft off-white/light gray with subtle blue-purple ambient glow) */}
      <div className="absolute -top-12 -left-12 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-1/3 -right-12 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-16 left-1/4 w-80 h-80 bg-fuchsia-500/5 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* =========================================================================
          FUTURISTIC HERO PROFILE CARD (Identitas Digital & Pencapaian Siswa)
          ========================================================================= */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#060a19] via-[#0c163b] to-[#190e3f] border border-indigo-500/30 text-white p-6 sm:p-8 shadow-[0_20px_50px_rgba(2,6,23,0.45),0_0_40px_rgba(59,130,246,0.18)]">
        {/* Futuristic digital grid texture */}
        <div className="absolute inset-0 bg-[radial-gradient(#38bdf815_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none opacity-50" />

        {/* Dynamic ambient glowing orbs */}
        <div className="absolute -top-24 -left-20 w-80 h-80 rounded-full bg-cyan-500/12 blur-3xl pointer-events-none animate-pulse-subtle" />
        <div className="absolute -bottom-28 -right-20 w-96 h-96 rounded-full bg-fuchsia-600/12 blur-3xl pointer-events-none" />
        <div className="absolute top-1/3 left-1/2 w-64 h-64 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none" />

        {/* Kelap-kelip Bintang (Twinkling Cosmic & Cyber Stars) */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
          {/* Star 1 - Top Left */}
          <div className="absolute top-[14%] left-[12%] animate-twinkle-1 pointer-events-none">
            <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-cyan-300/60 drop-shadow-[0_0_5px_rgba(56,189,248,0.7)]">
              <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
            </svg>
          </div>

          {/* Star 2 - Top Right */}
          <div className="absolute top-[20%] right-[16%] animate-twinkle-2 pointer-events-none">
            <svg viewBox="0 0 24 24" className="w-4 h-4 text-amber-300/60 drop-shadow-[0_0_6px_rgba(252,211,77,0.7)]">
              <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
            </svg>
          </div>

          {/* Star 3 - Center Top */}
          <div className="absolute top-[12%] left-[48%] animate-twinkle-3 pointer-events-none">
            <div className="w-1.5 h-1.5 rounded-full bg-white/70 shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
          </div>

          {/* Star 4 - Mid Left */}
          <div className="absolute top-[42%] left-[6%] animate-twinkle-4 pointer-events-none">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-300/60 shadow-[0_0_6px_rgba(56,189,248,0.8)]" />
          </div>

          {/* Star 5 - Mid Right */}
          <div className="absolute top-[40%] right-[8%] animate-twinkle-5 pointer-events-none">
            <svg viewBox="0 0 24 24" className="w-3 h-3 text-indigo-300/60 drop-shadow-[0_0_5px_rgba(165,180,252,0.7)]">
              <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
            </svg>
          </div>

          {/* Star 6 - Bottom Center */}
          <div className="absolute top-[75%] left-[55%] animate-twinkle-2 pointer-events-none">
            <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-300/60 shadow-[0_0_7px_rgba(240,171,252,0.8)]" />
          </div>

          {/* Star 7 - Bottom Right */}
          <div className="absolute top-[78%] right-[22%] animate-twinkle-1 pointer-events-none">
            <svg viewBox="0 0 24 24" className="w-3 h-3 text-cyan-200/50 drop-shadow-[0_0_4px_rgba(165,243,252,0.6)]">
              <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
            </svg>
          </div>

          {/* Star 8 - Top Mid-Left */}
          <div className="absolute top-[18%] left-[28%] animate-twinkle-6 pointer-events-none">
            <div className="w-1 h-1 rounded-full bg-amber-200/60 shadow-[0_0_5px_rgba(253,230,138,0.7)]" />
          </div>

          {/* Star 9 - Top Mid-Right */}
          <div className="absolute top-[28%] right-[32%] animate-twinkle-3 pointer-events-none">
            <svg viewBox="0 0 24 24" className="w-2.5 h-2.5 text-cyan-200/55 drop-shadow-[0_0_4px_rgba(165,243,252,0.6)]">
              <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
            </svg>
          </div>

          {/* Star 10 - Bottom Left */}
          <div className="absolute top-[82%] left-[18%] animate-twinkle-5 pointer-events-none">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-300/60 shadow-[0_0_6px_rgba(165,180,252,0.7)]" />
          </div>

          {/* Star 11 - Lower Mid-Left */}
          <div className="absolute top-[68%] left-[38%] animate-twinkle-4 pointer-events-none">
            <div className="w-1 h-1 rounded-full bg-white/60 shadow-[0_0_5px_rgba(255,255,255,0.7)]" />
          </div>

          {/* Star 12 - Far Top Right */}
          <div className="absolute top-[16%] right-[5%] animate-twinkle-1 pointer-events-none">
            <svg viewBox="0 0 24 24" className="w-3 h-3 text-fuchsia-300/55 drop-shadow-[0_0_5px_rgba(240,171,252,0.7)]">
              <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
            </svg>
          </div>

          {/* Star 13 - Mid Lower Right */}
          <div className="absolute top-[62%] right-[14%] animate-twinkle-6 pointer-events-none">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-300/60 shadow-[0_0_6px_rgba(103,232,249,0.7)]" />
          </div>

          {/* Star 14 - Bottom Center-Right */}
          <div className="absolute top-[85%] right-[44%] animate-twinkle-2 pointer-events-none">
            <div className="w-1 h-1 rounded-full bg-violet-300/60 shadow-[0_0_5px_rgba(196,181,253,0.7)]" />
          </div>
        </div>

        <div className="relative z-10 space-y-4 sm:space-y-6">
          {/* Baris Paling Atas Hero Card: Badge di Kiri & Tombol Keluar Fleksibel di Kanan Atas */}
          <div className="flex items-center justify-between gap-3 w-full border-b border-white/10 pb-3">
            {/* Badge Profil Murid */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/25 text-cyan-300 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>Profil Murid</span>
            </div>

            {/* Tombol Keluar Akun Fleksibel Berada pada Bagian Kanan Atas (Tanpa Tumpang Tindih Foto) */}
            <button
              id="btn-logout-profil"
              type="button"
              onClick={onLogout}
              className="min-h-[34px] sm:min-h-[38px] px-3 sm:px-4 py-1.5 rounded-xl bg-white/10 hover:bg-rose-500/25 text-slate-200 hover:text-rose-200 border border-white/15 hover:border-rose-500/40 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer backdrop-blur-md shadow-xs active:scale-95 shrink-0"
              title="Keluar dari akun murid"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span>Keluar Akun</span>
            </button>
          </div>

          {/* Konten Hero: Foto Profil & Identitas Murid (Diletakkan di Bawah Baris Atas, Dijamin Tidak Tumpang Tindih) */}
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6">
            {/* Avatar dengan Ring Gradient Biru-Ungu-Magenta & Soft Glow */}
            <div className="relative group shrink-0">
              <div
                onClick={handleOpenPhotoModal}
                className="relative p-[3px] rounded-[28px] bg-gradient-to-tr from-cyan-400 via-indigo-500 to-fuchsia-500 shadow-[0_0_28px_rgba(56,189,248,0.35)] cursor-pointer transition-all duration-300 group-hover:scale-105 group-hover:shadow-[0_0_38px_rgba(168,85,247,0.5)]"
                title="Klik untuk mengubah foto profil"
              >
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-[25px] bg-slate-950 overflow-hidden flex items-center justify-center relative">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.fullName || user.username}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="font-display font-black text-3xl sm:text-4xl text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-100 to-indigo-200">
                      {(user.fullName || user.username).charAt(0).toUpperCase()}
                    </span>
                  )}

                  {/* Hover Overlay Avatar */}
                  <div className="absolute inset-0 bg-slate-950/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white gap-1 backdrop-blur-xs">
                    <UserCheck className="w-6 h-6 text-cyan-300" />
                    <span className="text-[10px] font-bold tracking-wide">Pilih Avatar</span>
                  </div>
                </div>
              </div>

              {/* Tombol Pilih Avatar Aksi Cepat */}
              <button
                type="button"
                onClick={handleOpenPhotoModal}
                className="absolute -bottom-1 -left-1 p-1.5 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white shadow-lg border-2 border-slate-950 transition-transform active:scale-95 cursor-pointer z-10"
                title="Pilih Avatar Murid"
              >
                <User className="w-3.5 h-3.5" />
              </button>

              {/* Badge Level Modern */}
              <div className="absolute -bottom-2 -right-2 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 text-slate-950 font-mono font-black text-[11px] shadow-lg shadow-amber-500/30 border border-amber-200/60 z-10">
                LV {profile.level}
              </div>
            </div>

            {/* Identitas Murid di Bagian Tengah */}
            <div className="flex-1 text-center sm:text-left min-w-0">
              <div className="space-y-1">
                {/* Nama Utama Siswa */}
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-black text-white tracking-tight">
                  {(user.fullName || user.name || 'Aisyah Azzahra').replace(/\s*\([^)]*\)/g, '').trim()}
                </h1>

                {/* Username, Kelas & Tombol Pilih Avatar */}
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-0.5">
                  <span className="text-xs sm:text-sm text-slate-400 font-mono">
                    @{user.username}
                  </span>
                  <span className="text-slate-600">•</span>
                  <span className="text-xs sm:text-sm text-indigo-300 font-medium">
                    {(profile.className || 'XII-1').replace(/\s*MIPA/gi, '').trim()}
                  </span>
                  <span className="text-slate-600">•</span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-200 border border-indigo-500/30 text-xs font-bold font-mono">
                    <Users className="w-3 h-3 text-indigo-300" />
                    <span>{studentKelompok}</span>
                  </span>
                  <button
                    type="button"
                    onClick={handleOpenPhotoModal}
                    className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-white/10 hover:bg-white/15 text-slate-200 text-[11px] font-semibold border border-white/15 transition-all cursor-pointer backdrop-blur-xs ml-1 active:scale-95"
                  >
                    <User className="w-3 h-3 text-cyan-300" />
                    <span>Pilih Avatar</span>
                  </button>
                </div>

                {/* Informasi Kelompok & Teman-teman Sekelompok */}
                <div className="pt-2">
                  <div className="inline-flex flex-wrap items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/60 border border-indigo-500/25 text-xs backdrop-blur-xs">
                    <span className="font-semibold text-indigo-300 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-indigo-400" />
                      Rekan {studentKelompok}:
                    </span>
                    {teammates.length === 0 ? (
                      <span className="text-slate-400 text-[11px] italic">
                        Menunggu pembagian rekan sekelompok oleh guru.
                      </span>
                    ) : (
                      <div className="flex flex-wrap items-center gap-1.5">
                        {teammates.map((tm) => (
                          <span
                            key={tm.id}
                            className="px-2 py-0.5 rounded-md bg-white/10 text-slate-200 text-[11px] font-medium border border-white/10 hover:bg-white/20 transition-colors"
                          >
                            {tm.name || tm.user?.fullName || 'Murid'}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* =====================================================================
              STATISTIK PENCAPAIAN (Compact Achievement Cards di Bawah Hero Card)
              ===================================================================== */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3.5 pt-4 border-t border-white/10">
            {/* TOTAL XP (Aksen Kuning / Gold) */}
            <div className="group relative rounded-2xl bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/25 p-3 transition-all duration-200 hover:-translate-y-0.5 hover:border-amber-400/50 hover:shadow-[0_0_20px_rgba(245,158,11,0.15)]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-amber-300/80 uppercase tracking-wider">
                  TOTAL XP
                </span>
                <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-300">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-mono font-black text-amber-300 mt-1">
                {profile.xp} <span className="text-xs font-bold text-amber-400/80">XP</span>
              </div>
            </div>

            {/* LEVEL SAINS (Aksen Biru / Cyan) */}
            <div className="group relative rounded-2xl bg-gradient-to-br from-cyan-500/10 via-blue-500/5 to-transparent border border-cyan-500/25 p-3 transition-all duration-200 hover:-translate-y-0.5 hover:border-cyan-400/50 hover:shadow-[0_0_20px_rgba(6,182,212,0.15)]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-cyan-300/80 uppercase tracking-wider">
                  LEVEL SAINS
                </span>
                <div className="w-6 h-6 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-300">
                  <Award className="w-3.5 h-3.5 text-cyan-300" />
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-mono font-black text-cyan-300 mt-1">
                LEVEL {profile.level}
              </div>
            </div>

            {/* KONSISTENSI (Aksen Pink / Merah) */}
            <div className="group relative rounded-2xl bg-gradient-to-br from-rose-500/10 via-pink-500/5 to-transparent border border-rose-500/25 p-3 transition-all duration-200 hover:-translate-y-0.5 hover:border-rose-400/50 hover:shadow-[0_0_20px_rgba(244,63,94,0.15)]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-rose-300/80 uppercase tracking-wider">
                  KONSISTENSI
                </span>
                <div className="w-6 h-6 rounded-lg bg-rose-500/20 flex items-center justify-center text-rose-400">
                  <Flame className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-mono font-black text-rose-400 mt-1">
                {profile.streakDays} <span className="text-xs font-bold text-rose-400/80">HARI</span>
              </div>
            </div>

            {/* MISI TUNTAS (Aksen Hijau / Turquoise) */}
            <div className="group relative rounded-2xl bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-transparent border border-emerald-500/25 p-3 transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-400/50 hover:shadow-[0_0_20px_rgba(16,185,129,0.15)]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-emerald-300/80 uppercase tracking-wider">
                  MISI TUNTAS
                </span>
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
              </div>
              <div className="text-xl sm:text-2xl font-mono font-black text-emerald-400 mt-1">
                {completedCount} <span className="text-xs font-bold text-emerald-400/80">Misi</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          INFORMASI KELOMPOK BELAJAR & REKAN PRAKTIKUM (MIPA)
          ========================================================================= */}
      <div className="rounded-2xl bg-slate-900 border border-indigo-900/60 p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm sm:text-base font-display font-extrabold text-white">
                  Informasi Kelompok & Rekan Belajar
                </h2>
                <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                  {studentKelompok}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Kelas {profileState.className || 'XII-1'} • Data kelompok terhubung otomatis dari pemetaan guru
              </p>
            </div>
          </div>

          {onNavigateToLab && (
            <button
              type="button"
              onClick={onNavigateToLab}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer self-start sm:self-auto active:scale-95"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Buka Eksperimen Sensor</span>
            </button>
          )}
        </div>

        {/* Daftar Teman Satu Kelompok */}
        <div>
          <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
            Teman-Teman Satu Kelompok ({teammates.length} Murid):
          </div>
          {teammates.length === 0 ? (
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 text-xs text-slate-400 italic">
              Belum ada rekan yang dipetakan ke {studentKelompok}. Hubungi guru Anda untuk pembagian kelompok praktikum.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {teammates.map((tm) => (
                <div
                  key={tm.id}
                  className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/70 hover:border-indigo-500/40 transition-colors"
                >
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-500 to-purple-600 text-white flex items-center justify-center font-display font-bold text-xs shrink-0">
                    {(tm.name || tm.user?.fullName || 'M')[0]}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-xs text-slate-200 truncate">
                      {tm.name || tm.user?.fullName || 'Murid'}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono truncate">
                      {tm.nisn ? `NISN: ${tm.nisn}` : tm.email || tm.user?.username || 'Anggota Kelompok'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* =========================================================================
          LAPORAN MINGGUAN (Pelajaran Meningkat & Menurun, Buka untuk Detail)
          ========================================================================= */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 sm:p-5 shadow-sm space-y-2">
        {/* Header Komponen Ringkas */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 border-b border-slate-800/80 pb-2.5">
          <div>
            <h2 className="text-sm sm:text-base font-display font-extrabold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Laporan Perkembangan Mingguan</span>
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Ringkasan tren capaian: mata pelajaran yang meningkat dan menurun minggu ini.
            </p>
          </div>
          <span className="self-start sm:self-auto text-[11px] font-mono font-bold text-emerald-300 bg-emerald-500/10 border border-emerald-500/25 px-2.5 py-0.5 rounded-full whitespace-nowrap">
            Minggu Ini • Fase F
          </span>
        </div>

        {/* Layout List / Rows Ringkas */}
        <div className="divide-y divide-slate-800/80">
          {weeklyProgressData.length === 0 ? (
            <div className="py-6 text-center text-slate-400 space-y-2">
              <TrendingUp className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-300 font-semibold">
                Belum ada aktivitas mingguan yang tercatat.
              </p>
              <p className="text-[11px] text-slate-500 max-w-md mx-auto">
                Mulai kerjakan Misi Pembelajaran atau selesaikan eksperimen Virtual Lab untuk melihat analisis perkembangan belajar Anda secara otomatis dan nyata.
              </p>
            </div>
          ) : (
            weeklyProgressData.map((item) => {
              const isOpen = openReportId === item.id;
              const isMeningkat = item.trend === 'MENINGKAT';
              const IconComp = item.icon;

              return (
                <div key={item.id} className="py-2.5 transition-colors">
                  {/* Baris Utama: Desktop horizontal, Mobile 2 baris compact */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    {/* Sisi Kiri: Icon, Nama Pelajaran, Topik Singkat */}
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                          isMeningkat
                            ? 'bg-emerald-500/15 text-emerald-400'
                            : 'bg-rose-500/15 text-rose-400'
                        }`}
                      >
                        <IconComp className="w-3.5 h-3.5" />
                      </div>
                      <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5 min-w-0">
                        <span className="text-xs sm:text-sm font-bold text-white font-display whitespace-nowrap">
                          {item.subject.replace(/^Pelajaran\s+/i, '')}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono truncate">
                          {item.topic}
                        </span>
                      </div>
                    </div>

                    {/* Sisi Kanan: Badge Status Tren & Tombol Buka Deskripsi */}
                    <div className="flex items-center justify-between sm:justify-end gap-2 pl-9 sm:pl-0 shrink-0">
                      {/* Badge Tren Compact */}
                      <span
                        className={`text-[11px] font-mono font-semibold px-2 py-0.5 rounded-md border inline-flex items-center gap-1 ${
                          isMeningkat
                            ? 'text-emerald-300 bg-emerald-500/10 border-emerald-500/25'
                            : 'text-rose-300 bg-rose-500/10 border-rose-500/25'
                        }`}
                      >
                        {isMeningkat ? (
                          <>
                            <TrendingUp className="w-3 h-3 text-emerald-400" />
                            <span>Meningkat ({item.percentage})</span>
                          </>
                        ) : (
                          <>
                            <TrendingDown className="w-3 h-3 text-rose-400" />
                            <span>Menurun ({item.percentage})</span>
                          </>
                        )}
                      </span>

                      {/* Tombol Detail Text/Button Ringkas */}
                      <button
                        type="button"
                        onClick={() => setOpenReportId(isOpen ? null : item.id)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all border cursor-pointer active:scale-95 ${
                          isOpen
                            ? 'bg-slate-800 text-slate-200 border-slate-700'
                            : 'bg-slate-800/40 hover:bg-slate-800 text-slate-300 hover:text-white border-slate-700/60'
                        }`}
                      >
                        <Eye className="w-3 h-3 text-slate-400" />
                        <span>{isOpen ? 'Tutup' : 'Buka Deskripsi'}</span>
                        {isOpen ? (
                          <ChevronUp className="w-3 h-3 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-3 h-3 text-slate-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Deskripsi (Hanya muncul ketika diklik tombol Buka) */}
                  {isOpen && (
                    <div
                      className={`mt-2 ml-0 sm:ml-9 p-3 rounded-xl border text-xs space-y-1.5 animate-fadeIn ${
                        isMeningkat
                          ? 'bg-slate-950/60 border-emerald-500/20 text-slate-300'
                          : 'bg-slate-950/60 border-rose-500/20 text-slate-300'
                      }`}
                    >
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                          Kompetensi Terkait:
                        </span>{' '}
                        <span className="font-semibold text-white">{item.competency}</span>
                      </div>

                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                          Deskripsi Evaluasi:
                        </span>
                        <p className="text-slate-300 leading-relaxed text-[11px] mt-0.5">
                          {item.description}
                        </p>
                      </div>

                      <div
                        className={`pt-1.5 border-t text-[11px] flex items-start gap-1.5 ${
                          isMeningkat
                            ? 'border-emerald-500/20 text-emerald-300'
                            : 'border-rose-500/20 text-amber-300'
                        }`}
                      >
                        <span className="font-bold shrink-0">Rekomendasi:</span>
                        <span>{item.recommendation}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* =========================================================================
          PORTOFOLIO (Hanya Judul, Tanggal Upload, Total XP, dan Klik Buka)
          ========================================================================= */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-display font-extrabold text-white flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-blue-400" />
              <span>Portofolio & Karya Eksperimen</span>
            </h2>
          </div>

          {/* Tombol Upload Portofolio */}
          <button
            type="button"
            onClick={() => {
              setUploadSuccessMsg(null);
              setShowUploadPortfolioModal(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer self-start sm:self-auto border border-blue-400/30"
          >
            <Upload className="w-4 h-4" />
            <span>Upload Portofolio</span>
          </button>
        </div>

        {portfolios.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
            {portfolios.map((item) => {
              const thumb = getPortfolioThumbnail(item);

              return (
                <div
                  key={item.id}
                  className="group relative bg-slate-900 border border-slate-800/90 hover:border-indigo-500/40 p-4 sm:p-5 rounded-2xl transition-all duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-950/25 select-none flex flex-col justify-between overflow-hidden"
                >
                  {/* Subtle glowing gradient line accent on top */}
                  <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                  <div className="space-y-3">
                    {/* Thumbnail / Foto Dokumentasi Eksperimen jika tersedia */}
                    {thumb && (
                      <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden bg-slate-950 border border-slate-800/80 group-hover:border-slate-700 transition-colors">
                        <img
                          src={thumb}
                          alt={item.title}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-2 left-2">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-slate-950/85 backdrop-blur-md text-cyan-300 border border-cyan-500/30">
                            {item.category || 'Eksperimen'}
                          </span>
                        </div>
                        <div className="absolute bottom-2 right-2">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-950/85 backdrop-blur-md text-amber-300 border border-amber-500/30 flex items-center gap-1">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            +{item.xpEarned} XP
                          </span>
                        </div>
                      </div>
                    )}

                    <div>
                      {/* 1. Judul Portofolio */}
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider font-mono">
                          {item.subjectName || 'MIPA'}
                        </span>
                        {!thumb && (
                          <div className="flex items-center gap-1 text-amber-300 font-mono font-bold text-xs">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            <span>+{item.xpEarned} XP</span>
                          </div>
                        )}
                      </div>

                      <h3 className="text-base font-display font-bold text-white line-clamp-1 group-hover:text-cyan-200 transition-colors">
                        {item.title}
                      </h3>
                    </div>

                    {/* 2. Tanggal Upload & Total XP */}
                    <div className="flex items-center justify-between text-xs pt-2.5 border-t border-slate-800/80">
                      <div className="flex items-center gap-1.5 text-slate-400 font-mono">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{item.date}</span>
                      </div>

                      {thumb && (
                        <div className="flex items-center gap-1 text-amber-300 font-mono font-bold text-xs">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>+{item.xpEarned} XP</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 4. Klik Buka */}
                  <button
                    type="button"
                    onClick={() => setSelectedPortfolio(item)}
                    className="w-full mt-3 py-2 px-4 rounded-xl bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white border border-blue-500/30 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Klik Buka</span>
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="rounded-3xl p-8 bg-slate-900/60 border border-slate-800 text-center space-y-3">
            <FolderOpen className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-sm text-slate-400">
              Belum ada artefak portofolio tersimpan. Selesaikan eksperimen virtual lab untuk menerbitkan portofolio pertamamu!
            </p>
          </div>
        )}
      </div>

      {/* =========================================================================
          MODAL PILIH AVATAR PROFIL (Fleksibel HP, Tanpa Scroll, Ukuran Kotak Compact)
          ========================================================================= */}
      <Modal
        isOpen={showEditPhotoModal}
        onClose={() => setShowEditPhotoModal(false)}
        title="Pilih Avatar Murid"
        subtitle="Pilih karakter resmi untuk profil akun belajar Anda"
        maxWidth="md"
        bodyClassName="p-2.5 sm:p-4"
        headerClassName="px-3.5 sm:px-5 py-2 sm:py-3"
      >
        <div className="space-y-2.5 sm:space-y-3.5 text-slate-800">
          {/* Pratinjau Avatar Ringkas (Compact Horizontal Card agar tidak makan tinggi layar HP) */}
          <div className="flex items-center justify-between gap-2.5 p-2 sm:p-2.5 rounded-xl bg-white/95 border border-slate-200 shadow-xs">
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-pink-500 p-0.5 shadow-xs shrink-0">
                <div className="w-full h-full rounded-[9px] bg-slate-900 overflow-hidden flex items-center justify-center">
                  {previewAvatar ? (
                    <img
                      src={previewAvatar}
                      alt="Preview Avatar Profil"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <span className="font-display font-black text-lg sm:text-xl text-white">
                      {(user.fullName || user.username).charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>
              </div>
              <div className="min-w-0">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                  Pratinjau Avatar Terpilih
                </span>
                <p className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                  {previewAvatar ? 'Avatar Profil Murid' : 'Menggunakan inisial nama'}
                </p>
              </div>
            </div>

            <span className="shrink-0 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[9px] sm:text-[10px] font-bold border border-emerald-200">
              {previewAvatar ? 'Terpilih' : 'Inisial'}
            </span>
          </div>

          {/* Opsi Pilihan Avatar: 3 Kotak Berjejer Rapi (grid-cols-3) Tanpa Tulisan (Hanya Foto Saja) */}
          <div className="space-y-1 sm:space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[10px] sm:text-xs font-bold text-slate-700 uppercase tracking-wider block">
                Pilih Karakter Avatar:
              </label>
              <span className="text-[9px] sm:text-[10px] text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                3 Pilihan
              </span>
            </div>

            {/* Grid 3 Kolom Responsif - Hanya Foto Saja Tanpa Tulisan */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              {STUDENT_AVATAR_OPTIONS.map((item) => {
                const isSelected = previewAvatar === item.url;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setPreviewAvatar(item.url)}
                    className={`relative p-1.5 sm:p-2.5 rounded-xl sm:rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-center group ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/90 ring-2 ring-blue-400/50 shadow-md scale-[1.02]'
                        : 'border-slate-200 bg-white hover:border-blue-300 hover:bg-slate-50'
                    }`}
                  >
                    {/* Kotak Avatar - Hanya Foto Saja Tanpa Tulisan */}
                    <div className="relative w-14 h-14 sm:w-20 sm:h-20 aspect-square rounded-lg sm:rounded-xl overflow-hidden shadow-xs border border-slate-100 group-hover:scale-105 transition-transform bg-slate-900 shrink-0">
                      <img
                        src={item.url}
                        alt="Avatar Murid"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {isSelected && (
                        <div className="absolute top-1 right-1 sm:top-1.5 sm:right-1.5 w-4 h-4 sm:w-5 sm:h-5 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-xs">
                          <Check className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5" />
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notification message */}
          {photoSaveMessage && (
            <div className="p-1.5 sm:p-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-800 text-[10px] sm:text-xs font-bold flex items-center gap-1.5 animate-fadeIn">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>{photoSaveMessage}</span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2 sm:pt-2.5 border-t border-slate-200 gap-1.5">
            <button
              type="button"
              onClick={handleResetAvatar}
              className="px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg sm:rounded-xl text-[10px] sm:text-xs font-bold text-slate-600 hover:text-red-600 hover:bg-red-50 transition-colors flex items-center gap-1 cursor-pointer shrink-0"
              title="Gunakan inisial nama"
            >
              <RefreshCw className="w-3 h-3" />
              <span className="hidden xs:inline">Gunakan </span>Inisial
            </button>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setShowEditPhotoModal(false)}
                className="px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-lg sm:rounded-xl border border-slate-300 text-slate-700 text-[10px] sm:text-xs font-bold hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleSaveAvatar}
                disabled={!previewAvatar}
                className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg sm:rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-[10px] sm:text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer"
              >
                Simpan Avatar
              </button>
            </div>
          </div>
        </div>
      </Modal>

      {/* Portfolio Detail Modal */}
      {selectedPortfolio && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 sm:p-8 text-white space-y-5 my-auto shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-mono font-bold text-blue-400 uppercase tracking-wider">
                  {selectedPortfolio.category} • {selectedPortfolio.subjectName}
                </span>
                <h2 className="text-xl sm:text-2xl font-display font-extrabold text-white mt-1">
                  {selectedPortfolio.title}
                </h2>
                <p className="text-xs text-slate-400 font-mono mt-1">
                  Diterbitkan pada {selectedPortfolio.date} oleh {selectedPortfolio.studentName || user.fullName}
                </p>
              </div>

              <div className="flex items-center gap-1 font-mono font-bold text-amber-300 bg-amber-500/20 px-3 py-1.5 rounded-xl border border-amber-400/30">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                +{selectedPortfolio.xpEarned} XP
              </div>
            </div>

            {/* Foto Dokumentasi Portofolio jika ada */}
            {selectedPortfolio.documentation && (
              <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-slate-800 border border-slate-700">
                <img
                  src={selectedPortfolio.documentation}
                  alt={selectedPortfolio.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-2.5 left-2.5">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-900/80 backdrop-blur-md text-emerald-400 border border-emerald-500/30">
                    Foto Dokumentasi Murid
                  </span>
                </div>
              </div>
            )}

            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
              <div className="text-xs font-mono font-bold text-slate-300 uppercase">
                Ringkasan Refleksi & Temuan:
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                {selectedPortfolio.reflectionSummary}
              </p>
            </div>

            {selectedPortfolio.conclusion && (
              <div className="p-4 rounded-2xl bg-blue-950/40 border border-blue-500/30 space-y-2">
                <div className="text-xs font-mono font-bold text-blue-300 uppercase">
                  Kesimpulan Saintifik:
                </div>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  {selectedPortfolio.conclusion}
                </p>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => handleDeletePortfolio(selectedPortfolio.id)}
                className="px-4 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Hapus Portofolio</span>
              </button>

              <button
                onClick={() => setSelectedPortfolio(null)}
                className="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Upload Portofolio Murid */}
      <UploadPortfolioModal
        isOpen={showUploadPortfolioModal}
        onClose={() => setShowUploadPortfolioModal(false)}
        onSuccess={() => {
          onRefreshPortfolios();
        }}
        studentId={profile.student?.id || `std-${user.id}`}
        studentName={user.fullName || user.username}
        classId={profile.student?.classId || 'cls-xii-1'}
        className={profile.className || 'XII-1'}
      />
    </div>
  );
};
