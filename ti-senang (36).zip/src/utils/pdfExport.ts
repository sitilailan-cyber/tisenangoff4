import { jsPDF } from 'jspdf';
import { AsesmenAwalInput, Student, User } from '../types';

export interface ExportAsesmenPdfParams {
  className: string;
  subjectName: string;
  teacherName: string;
  assessmentData: AsesmenAwalInput[];
  students: Array<Student & { user?: User; className?: string }> | Student[];
}

export function exportAsesmenToPdf(params: ExportAsesmenPdfParams): void {
  const { className, subjectName, teacherName, assessmentData } = params;
  const doc = new jsPDF();

  // Header
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN ASESMEN AWAL DIAGNOSTIK MIPA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mata Pelajaran : ${subjectName}`, 14, 28);
  doc.text(`Kelas          : ${className}`, 14, 34);
  doc.text(`Guru Pengampu  : ${teacherName}`, 14, 40);
  doc.text(`Tanggal Cetak  : ${new Date().toLocaleDateString('id-ID')}`, 14, 46);

  // Table header
  let startY = 56;
  doc.setFillColor(30, 41, 59);
  doc.rect(14, startY, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('No', 16, startY + 5.5);
  doc.text('Nama Murid', 26, startY + 5.5);
  doc.text('Diagnostik', 90, startY + 5.5);
  doc.text('Literasi', 112, startY + 5.5);
  doc.text('Numerasi', 130, startY + 5.5);
  doc.text('Penalaran', 150, startY + 5.5);
  doc.text('Kesiapan', 170, startY + 5.5);

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  let currentY = startY + 8;

  assessmentData.forEach((row, idx) => {
    if (currentY > 270) {
      doc.addPage();
      currentY = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(241, 245, 249);
      doc.rect(14, currentY, 182, 7, 'F');
    }

    doc.text(String(idx + 1), 16, currentY + 5);
    doc.text((row.studentName || 'Murid').slice(0, 26), 26, currentY + 5);
    doc.text(String(row.diagnosticScore), 94, currentY + 5);
    doc.text(String(row.literacyScore), 116, currentY + 5);
    doc.text(String(row.numeracyScore), 134, currentY + 5);
    doc.text(String(row.reasoningScore), 154, currentY + 5);
    doc.text((row.readinessLevel || 'Berkembang').slice(0, 14), 170, currentY + 5);

    currentY += 7;
  });

  // Footer summary
  currentY += 8;
  if (currentY > 260) {
    doc.addPage();
    currentY = 20;
  }

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text(
    '* Laporan ini diunduh secara otomatis dari sistem pembelajaran adaptif TI SENANG.',
    14,
    currentY,
  );

  doc.save(`Asesmen_Awal_${className}_${subjectName.replace(/\s+/g, '_')}.pdf`);
}

export interface ExportAsesmenAkhirPdfParams {
  className: string;
  subjectName: string;
  teacherName: string;
  kktpTarget?: number;
  records: Array<{
    studentName: string;
    nisn?: string;
    score: number;
    kktpStatus: 'Tuntas' | 'Belum Tuntas';
    predikat: string;
    tpMasteryPercentage: number;
    catatan?: string;
  }>;
}

export function exportAsesmenAkhirToPdf(params: ExportAsesmenAkhirPdfParams): void {
  const { className, subjectName, teacherName, kktpTarget = 75, records } = params;
  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN ASESMEN SUMATIF AKHIR MIPA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mata Pelajaran    : ${subjectName}`, 14, 28);
  doc.text(`Kelas             : ${className}`, 14, 34);
  doc.text(`Guru Pengampu     : ${teacherName}`, 14, 40);
  doc.text(`Kriteria Ketuntasan (KKTP) : ≥ ${kktpTarget}`, 14, 46);
  doc.text(`Tanggal Cetak     : ${new Date().toLocaleDateString('id-ID')}`, 14, 52);

  // Table header
  let startY = 60;
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(14, startY, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('No', 16, startY + 5.5);
  doc.text('Nama Murid', 26, startY + 5.5);
  doc.text('Nilai Akhir', 88, startY + 5.5);
  doc.text('Ketuntasan KKTP', 112, startY + 5.5);
  doc.text('Predikat', 148, startY + 5.5);
  doc.text('Capaian TP', 170, startY + 5.5);

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  let currentY = startY + 8;

  records.forEach((row, idx) => {
    if (currentY > 270) {
      doc.addPage();
      currentY = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, currentY, 182, 7, 'F');
    }

    doc.text(String(idx + 1), 16, currentY + 5);
    doc.text((row.studentName || 'Murid').slice(0, 28), 26, currentY + 5);
    doc.text(String(row.score), 94, currentY + 5);

    if (row.kktpStatus === 'Tuntas') {
      doc.setTextColor(16, 185, 129); // emerald green
    } else {
      doc.setTextColor(225, 29, 72); // rose red
    }
    doc.text(row.kktpStatus, 114, currentY + 5);

    doc.setTextColor(0, 0, 0);
    doc.text((row.predikat || 'B').slice(0, 10), 148, currentY + 5);
    doc.text(`${row.tpMasteryPercentage}%`, 172, currentY + 5);

    currentY += 7;
  });

  // Footer summary
  currentY += 10;
  if (currentY > 255) {
    doc.addPage();
    currentY = 20;
  }

  const totalSiswa = records.length;
  const tuntasCount = records.filter((r) => r.kktpStatus === 'Tuntas').length;
  const avgScore = totalSiswa
    ? (records.reduce((acc, r) => acc + r.score, 0) / totalSiswa).toFixed(1)
    : '0';

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Ringkasan Capaian Kelas:`, 14, currentY);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `• Rata-rata Nilai: ${avgScore}  |  • Ketuntasan Klasikal: ${tuntasCount}/${totalSiswa} Murid (${
      totalSiswa ? Math.round((tuntasCount / totalSiswa) * 100) : 0
    }%)`,
    14,
    currentY + 6,
  );

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text(
    '* Laporan Asesmen Akhir ini diverifikasi dan diunduh dari modul evaluasi adaptif TI SENANG.',
    14,
    currentY + 14,
  );

  doc.save(`Asesmen_Akhir_${className}_${subjectName.replace(/\s+/g, '_')}.pdf`);
}

export interface ExportRefleksiPdfParams {
  studentName: string;
  className: string;
  subjectName?: string;
  teacherName?: string;
  missionTitle: string;
  submittedAt: string;
  reflectionAnswers: {
    pemahaman?: string;
    tantangan?: string;
    halMenarik?: string;
    rencanaPerbaikan?: string;
    [key: string]: string | undefined;
  };
  selfAssessment: {
    kemandirian?: number;
    pemahamanKonsep?: number;
    keterampilanAnalisis?: number;
    sikapReflektif?: number;
    totalScorePercentage?: number;
    komitmen?: string;
  };
}

export function exportRefleksiToPdf(params: any): void {
  const studentName = params.studentName || 'Murid TI SENANG';
  const className = params.className || 'Kelas Fase F';
  const subjectName = params.subjectName || 'Fisika & MIPA Terapan';
  const teacherName = params.teacherName || 'Guru Pengampu MIPA';
  const missionTitle = params.missionTitle || 'Misi 5 • Refleksi & Penilaian Diri';
  const submittedAt = params.submittedAt || new Date().toISOString();

  // Normalize reflection answers whether passed as array or object
  let reflectionAnswers: any = {};
  if (Array.isArray(params.refleksiAnswers)) {
    reflectionAnswers = {
      pemahaman: params.refleksiAnswers[0] || 'Konsep regresi linear dan Azas Black.',
      tantangan: params.refleksiAnswers[1] || 'Menganalisis kemiringan grafik regresi.',
      halMenarik: params.refleksiAnswers[2] || 'Pengambilan data sensor otomatis.',
      rencanaPerbaikan: params.refleksiAnswers[3] || 'Lebih teliti dalam mencatat satuan.',
    };
  } else if (params.reflectionAnswers) {
    reflectionAnswers = params.reflectionAnswers;
  }

  // Normalize self assessment
  const rawSelf = params.selfAssessment || {};
  const selfAssessment = {
    kemandirian: rawSelf.kemandirian || 3,
    pemahamanKonsep: rawSelf.pemahamanKonsep || 3,
    keterampilanAnalisis: rawSelf.keterampilanAnalisis || rawSelf.keterampilanData || 3,
    sikapReflektif: rawSelf.sikapReflektif || rawSelf.sikapKritis || 4,
    totalScorePercentage: params.averageSelfScore || rawSelf.totalScorePercentage || 85,
    komitmen: rawSelf.komitmen || rawSelf.komitmenDiri || '',
  };

  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN REFLEKSI & PENILAIAN DIRI MURID', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nama Murid    : ${studentName}`, 14, 28);
  doc.text(`Kelas         : ${className}`, 14, 34);
  doc.text(`Mata Pelajaran: ${subjectName}`, 14, 40);
  doc.text(`Guru Pengampu : ${teacherName}`, 14, 46);
  doc.text(`Misi Terkait  : ${missionTitle}`, 14, 52);
  doc.text(
    `Waktu Kirim   : ${new Date(submittedAt || Date.now()).toLocaleString('id-ID')}`,
    14,
    58,
  );

  let currentY = 66;

  // BAGIAN 1: PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT)
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('A. HASIL PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT RUBRIC)', 16, currentY + 5);

  currentY += 10;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);

  const selfItems = [
    { label: 'Kemandirian & Keaktifan Belajar', val: selfAssessment.kemandirian || 4 },
    { label: 'Pemahaman Konsep & Penalaran Ilmiah', val: selfAssessment.pemahamanKonsep || 4 },
    { label: 'Keterampilan Analisis Data & Eksperimen', val: selfAssessment.keterampilanAnalisis || 4 },
    { label: 'Sikap Kritis, Teliti & Bertanggung Jawab', val: selfAssessment.sikapReflektif || 4 },
  ];

  selfItems.forEach((item, idx) => {
    const starStr = '★'.repeat(item.val) + '☆'.repeat(4 - item.val);
    const scoreVal = `${item.val} / 4  (${starStr})`;
    doc.text(`${idx + 1}. ${item.label}`, 16, currentY);
    doc.setFont('helvetica', 'bold');
    doc.text(scoreVal, 150, currentY);
    doc.setFont('helvetica', 'normal');
    currentY += 6;
  });

  const totalPercent = selfAssessment.totalScorePercentage || 95;
  currentY += 2;
  doc.setFont('helvetica', 'bold');
  doc.text(`Tingkat Capaian Penilaian Diri: ${totalPercent}% (${totalPercent >= 85 ? 'Sangat Baik' : totalPercent >= 75 ? 'Baik' : 'Perlu Bimbingan'})`, 16, currentY);
  doc.setFont('helvetica', 'normal');

  if (selfAssessment.komitmen) {
    currentY += 6;
    doc.setFont('helvetica', 'italic');
    doc.text(`Komitmen Diri: "${selfAssessment.komitmen}"`, 16, currentY, { maxWidth: 178 });
    currentY += 8;
  } else {
    currentY += 6;
  }

  currentY += 4;

  // BAGIAN 2: REFLEKSI PEMBELAJARAN
  doc.setFillColor(30, 41, 59);
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('B. HASIL REFLEKSI PEMBELAJARAN MURID', 16, currentY + 5);

  currentY += 11;
  doc.setTextColor(0, 0, 0);

  const questionsMap = [
    {
      q: '1. Konsep sains / materi yang paling dipahami dengan baik:',
      a: reflectionAnswers.pemahaman || 'Murid telah memahami konsep materi dan penerapannya dengan baik.',
    },
    {
      q: '2. Tantangan atau kesulitan yang dihadapi & solusinya:',
      a: reflectionAnswers.tantangan || 'Tantangan dapat diselesaikan melalui analisis mandiri dan bantuan bimbingan guru.',
    },
    {
      q: '3. Hal atau fenomena yang paling menarik dalam pembelajaran ini:',
      a: reflectionAnswers.halMenarik || 'Eksperimen sensor langsung dan simulasi grafis memudahkan visualisasi hubungan antarvariabel.',
    },
    {
      q: '4. Rencana aksi untuk meningkatkan pemahaman pada topik berikutnya:',
      a: reflectionAnswers.rencanaPerbaikan || 'Membaca modul pengayaan lebih awal dan memperbanyak latihan penalaran kontekstual.',
    },
  ];

  questionsMap.forEach((item) => {
    if (currentY > 260) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(item.q, 16, currentY);
    currentY += 5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const splitText = doc.splitTextToSize(item.a, 175);
    doc.text(splitText, 18, currentY);
    currentY += splitText.length * 4.5 + 4;
  });

  // Footer & Tanda Tangan
  if (currentY > 240) {
    doc.addPage();
    currentY = 25;
  } else {
    currentY += 10;
  }

  const signY = currentY + 10;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', 14, signY);
  doc.text('Guru Pengampu MIPA', 14, signY + 5);
  doc.text('_________________________', 14, signY + 22);
  doc.text(teacherName, 14, signY + 27);

  doc.text('Murid Bersangkutan,', 140, signY);
  doc.text('Kelas ' + className, 140, signY + 5);
  doc.text('_________________________', 140, signY + 22);
  doc.text(studentName, 140, signY + 27);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.text(
    '* Dokumen Refleksi & Penilaian Diri ini dibuat dan diunduh dari Platform Pembelajaran Adaptif TI SENANG.',
    14,
    signY + 36,
  );

  const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
  const safeName = cleanStudentName.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_\-]/g, '');
  const safeClass = (className || 'XII-1').replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_\-]/g, '');
  doc.save(`Refleksi_${safeName}_${safeClass}.pdf`);
}

export interface ExportStudentAsesmenAkhirPdfParams {
  studentName: string;
  className: string;
  subjectName?: string;
  teacherName?: string;
  missionTitle?: string;
  score: number;
  kktpStatus?: string;
  predikat?: string;
  submittedAt?: string;
  questions?: Array<{
    prompt: string;
    category?: string;
    studentAnswer?: any;
    correctAnswer?: any;
    points?: number;
    explanation?: string;
  }>;
}

export function exportStudentAsesmenAkhirToPdf(params: ExportStudentAsesmenAkhirPdfParams): void {
  const cleanStudentName = (params.studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
  const className = (params.className || 'XII-1').replace(/\s*\([^)]*\)/g, '').trim();
  const subjectName = params.subjectName || 'Fisika & MIPA Fase F';
  const teacherName = params.teacherName || 'Guru Pengampu MIPA';
  const missionTitle = params.missionTitle || 'Misi 6 • Asesmen Akhir Komprehensif MIPA';
  const submittedAt = params.submittedAt || new Date().toISOString();
  const score = params.score ?? 0;
  const kktpStatus = params.kktpStatus || (score >= 75 ? 'Tuntas' : 'Belum Tuntas');
  const predikat =
    params.predikat ||
    (score >= 88
      ? 'A (Sangat Baik)'
      : score >= 75
      ? 'B (Baik)'
      : score >= 65
      ? 'C (Cukup)'
      : 'D (Perlu Bimbingan)');

  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LEMBAR HASIL ASESMEN AKHIR MIPA', 14, 20);

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nama Murid    : ${cleanStudentName}`, 14, 28);
  doc.text(`Kelas         : ${className}`, 14, 34);
  doc.text(`Mata Pelajaran: ${subjectName}`, 14, 40);
  doc.text(`Guru Pengampu : ${teacherName}`, 14, 46);
  doc.text(`Misi Terkait  : ${missionTitle}`, 14, 52);
  doc.text(`Waktu Pengerjaan : ${new Date(submittedAt).toLocaleString('id-ID')}`, 14, 58);

  // Score Banner Card
  doc.setFillColor(30, 41, 59);
  doc.roundedRect(14, 64, 182, 22, 2, 2, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.text('HASIL CAPAIAN ASESMEN SUMATIF AKHIR', 20, 72);

  doc.setFontSize(15);
  doc.setTextColor(253, 224, 71);
  doc.text(`Nilai Akhir: ${score} / 100`, 20, 81);

  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text(`Status KKTP : ${kktpStatus} (Kriteria ≥ 75)`, 105, 73);
  doc.text(`Predikat    : ${predikat}`, 105, 80);

  let currentY = 94;

  // Question details if provided
  if (params.questions && params.questions.length > 0) {
    doc.setFillColor(241, 245, 249);
    doc.rect(14, currentY, 182, 7, 'F');
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('RINCIAN PENGERJAAN SOAL ASESMEN', 16, currentY + 5);
    currentY += 11;

    params.questions.forEach((q, idx) => {
      if (currentY > 255) {
        doc.addPage();
        currentY = 20;
      }

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(30, 41, 59);
      const categoryLabel = q.category ? `[${q.category.toUpperCase().replace('_', ' ')}] ` : '';
      const promptLines = doc.splitTextToSize(`${idx + 1}. ${categoryLabel}${q.prompt}`, 178);
      doc.text(promptLines, 16, currentY);
      currentY += promptLines.length * 4 + 2;

      // Student Answer
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(51, 65, 85);
      let ansStr = '-';
      if (Array.isArray(q.studentAnswer)) {
        ansStr = q.studentAnswer.join(', ');
      } else if (typeof q.studentAnswer === 'object' && q.studentAnswer !== null) {
        ansStr = Object.entries(q.studentAnswer)
          .map(([k, v]) => `${k}: ${v}`)
          .join('; ');
      } else if (q.studentAnswer !== undefined && q.studentAnswer !== null && String(q.studentAnswer).trim()) {
        ansStr = String(q.studentAnswer);
      }
      const ansLines = doc.splitTextToSize(`Jawaban Siswa: ${ansStr}`, 174);
      doc.text(ansLines, 20, currentY);
      currentY += ansLines.length * 3.8 + 2;

      // Correct / Explanation
      if (q.correctAnswer) {
        let corrStr = Array.isArray(q.correctAnswer) ? q.correctAnswer.join(', ') : String(q.correctAnswer);
        const corrLines = doc.splitTextToSize(`Kunci/Pembahasan: ${corrStr}`, 174);
        doc.setTextColor(15, 118, 110);
        doc.text(corrLines, 20, currentY);
        currentY += corrLines.length * 3.8 + 3;
      } else {
        currentY += 2;
      }
    });
  }

  // Footer & Signatures
  if (currentY > 235) {
    doc.addPage();
    currentY = 25;
  } else {
    currentY += 10;
  }

  const signY = currentY + 8;
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', 14, signY);
  doc.text('Guru Pengampu MIPA', 14, signY + 5);
  doc.text('_________________________', 14, signY + 20);
  doc.text(teacherName, 14, signY + 25);

  doc.text('Murid Peserta Asesmen,', 135, signY);
  doc.text('Kelas ' + className, 135, signY + 5);
  doc.text('_________________________', 135, signY + 20);
  doc.text(cleanStudentName, 135, signY + 25);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text(
    '* Lembar hasil asesmen akhir sumatif ini diunduh otomatis dari Platform Pembelajaran Adaptif TI SENANG.',
    14,
    signY + 34,
  );

  const safeName = cleanStudentName.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_\-]/g, '');
  const safeClass = className.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_\-]/g, '');
  doc.save(`Asesmen_Akhir_${safeName}_${safeClass}.pdf`);
}

export interface ExportMisi2PdfParams {
  studentName: string;
  className: string;
  subjectName?: string;
  teacherName?: string;
  missionTitle?: string;
  portfolioTitle: string;
  tpCode?: string;
  tpTitle?: string;
  contextualProblem?: string;
  tableRows?: Array<{ waktu: number; suhuAwal: number; intensitasCahaya: number; suhuAkhir: number }>;
  regressionStats?: {
    equation: string;
    r: number;
    r2: number;
    correlationDesc: string;
    interpretasiFisis: string;
  };
  analysisAnswers?: {
    q1_amat?: string;
    q2_pola?: string;
    q3_sebabSuhu?: string;
    q4_hubunganVariabel?: string;
  };
  laporanCatatan?: string;
  conclusion: string;
  photoDataUrl?: string;
  submittedAt?: string;
}

export function exportMisi2ExperimentToPdf(params: ExportMisi2PdfParams): void {
  const studentName = params.studentName || 'Murid MIPA';
  const className = params.className || 'Kelas XII Fase F';
  const subjectName = params.subjectName || 'Fisika Eksperimental & Terapan';
  const teacherName = params.teacherName || 'Guru Pengampu MIPA';
  const missionTitle = params.missionTitle || 'Misi 2 • Selesaikan Masalah';
  const portfolioTitle = params.portfolioTitle || 'Laporan Hasil Penyelidikan & Eksperimen MIPA';
  const submittedAt = params.submittedAt || new Date().toISOString();

  const doc = new jsPDF();

  // Header Banner
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN EKSPERIMEN & PENYELESAIAN MASALAH MIPA', 14, 18);

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nama Murid    : ${studentName}`, 14, 25);
  doc.text(`Kelas         : ${className}`, 14, 30);
  doc.text(`Mata Pelajaran: ${subjectName}`, 14, 35);
  doc.text(`Guru Pengampu : ${teacherName}`, 14, 40);
  doc.text(`Misi Terkait  : ${missionTitle}`, 14, 45);
  doc.text(`Tanggal Cetak : ${new Date(submittedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, 14, 50);

  let currentY = 56;

  // Judul Portofolio & Tujuan Pembelajaran
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('A. INFORMASI TOPIK & TUJUAN PEMBELAJARAN (TP)', 16, currentY + 5);

  currentY += 11;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Judul Portofolio: "${portfolioTitle}"`, 14, currentY);
  currentY += 5;

  if (params.tpCode || params.tpTitle) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const tpText = `Tujuan Pembelajaran: [${params.tpCode || 'TP'}] ${params.tpTitle || 'Penyelidikan Konsep Saintifik & Eksperimen'}`;
    const splitTp = doc.splitTextToSize(tpText, 180);
    doc.text(splitTp, 14, currentY);
    currentY += splitTp.length * 4.5 + 2;
  }

  // Tabel Data Pengamatan
  const rows = params.tableRows || [];
  if (rows.length > 0) {
    currentY += 2;
    doc.setFillColor(15, 23, 42);
    doc.rect(14, currentY, 182, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text('B. TABEL DATA HASIL EKSPERIMEN & PENGAMATAN SENSOR', 16, currentY + 5);

    currentY += 9;
    // Table Header
    doc.setFillColor(241, 245, 249);
    doc.rect(14, currentY, 182, 6, 'F');
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text('No', 16, currentY + 4.5);
    doc.text('Waktu (menit)', 30, currentY + 4.5);
    doc.text('Suhu Awal (°C)', 70, currentY + 4.5);
    doc.text('Intensitas Cahaya (Lux)', 110, currentY + 4.5);
    doc.text('Suhu Akhir (°C)', 160, currentY + 4.5);

    currentY += 6;
    doc.setFont('helvetica', 'normal');

    rows.slice(0, 15).forEach((row, i) => {
      if (currentY > 270) {
        doc.addPage();
        currentY = 20;
      }
      if (i % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, currentY, 182, 5.5, 'F');
      }
      doc.text(String(i + 1), 16, currentY + 4);
      doc.text(String(row.waktu), 30, currentY + 4);
      doc.text(row.suhuAwal.toFixed(1), 70, currentY + 4);
      doc.text(String(row.intensitasCahaya), 110, currentY + 4);
      doc.text(row.suhuAkhir.toFixed(1), 160, currentY + 4);
      currentY += 5.5;
    });
  }

  // Analisis Regresi Linear & Matematika
  if (params.regressionStats) {
    if (currentY > 240) {
      doc.addPage();
      currentY = 20;
    } else {
      currentY += 4;
    }

    doc.setFillColor(15, 23, 42);
    doc.rect(14, currentY, 182, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text('C. ANALISIS MATEMATIS & REGRESI DATA BIVARIAT', 16, currentY + 5);

    currentY += 10;
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);

    doc.text(`• Persamaan Garis Regresi : ${params.regressionStats.equation}`, 16, currentY);
    currentY += 5;
    doc.text(`• Koefisien Korelasi (r)  : ${params.regressionStats.r.toFixed(3)}  |  Koefisien Determinasi (R²): ${(params.regressionStats.r2 * 100).toFixed(1)}%`, 16, currentY);
    currentY += 5;
    doc.text(`• Klasifikasi Korelasi   : ${params.regressionStats.correlationDesc}`, 16, currentY);
    currentY += 5;
    const splitInterp = doc.splitTextToSize(`• Makna Fisis : ${params.regressionStats.interpretasiFisis}`, 178);
    doc.text(splitInterp, 16, currentY);
    currentY += splitInterp.length * 4.5 + 2;
  }

  // Kesimpulan Saintifik
  if (currentY > 230) {
    doc.addPage();
    currentY = 20;
  } else {
    currentY += 4;
  }

  doc.setFillColor(15, 23, 42);
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('D. KESIMPULAN SAINTIFIK & REFLEKSI PELAKSANAAN', 16, currentY + 5);

  currentY += 10;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Kesimpulan Siswa:', 16, currentY);
  currentY += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  const splitConc = doc.splitTextToSize(params.conclusion || 'Berdasarkan hasil eksperimen, data pengamatan terbukti konsisten dengan teori yang dipelajari.', 178);
  doc.text(splitConc, 16, currentY);
  currentY += splitConc.length * 4.5 + 4;

  if (params.laporanCatatan) {
    if (currentY > 250) {
      doc.addPage();
      currentY = 20;
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('Catatan Pelaksanaan / Prosedur:', 16, currentY);
    currentY += 5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const splitCatatan = doc.splitTextToSize(params.laporanCatatan, 178);
    doc.text(splitCatatan, 16, currentY);
    currentY += splitCatatan.length * 4.5 + 4;
  }

  // Tanda Tangan
  if (currentY > 240) {
    doc.addPage();
    currentY = 25;
  } else {
    currentY += 8;
  }

  const signY = currentY + 8;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', 14, signY);
  doc.text('Guru Pengampu MIPA', 14, signY + 5);
  doc.text('_________________________', 14, signY + 22);
  doc.text(teacherName, 14, signY + 27);

  doc.text('Murid Bersangkutan,', 140, signY);
  doc.text('Kelas ' + className, 140, signY + 5);
  doc.text('_________________________', 140, signY + 22);
  doc.text(studentName, 140, signY + 27);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.text(
    '* Dokumen Laporan Eksperimen Misi 2 ini diunduh secara resmi dari platform pembelajaran adaptif TI SENANG.',
    14,
    signY + 36,
  );

  const cleanName = studentName.replace(/[^a-zA-Z0-9_-]/g, '_');
  doc.save(`Laporan_Misi2_${cleanName}_${new Date().toISOString().slice(0, 10)}.pdf`);
}
