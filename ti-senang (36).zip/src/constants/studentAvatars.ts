// Pilihan avatar resmi untuk profil siswa:
// 1. Siswa Cowok
// 2. Siswa Cewek Tidak Berjilbab
// 3. Siswa Cewek Berjilbab

export interface StudentAvatarOption {
  id: string;
  label: string;
  category: string;
  description: string;
  url: string;
}

const AVATAR_COWOK_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
  <defs>
    <linearGradient id="bgCowok" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1e3a8a"/>
      <stop offset="50%" stop-color="#2563eb"/>
      <stop offset="100%" stop-color="#0284c7"/>
    </linearGradient>
    <linearGradient id="skinCowok" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fed7aa"/>
      <stop offset="100%" stop-color="#fdba74"/>
    </linearGradient>
    <linearGradient id="hairCowok" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#334155"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
    <linearGradient id="shirtCowok" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#e2e8f0"/>
    </linearGradient>
    <filter id="shadowCowok" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000" flood-opacity="0.16"/>
    </filter>
  </defs>
  <rect width="200" height="200" rx="44" fill="url(#bgCowok)"/>
  <circle cx="100" cy="100" r="88" fill="none" stroke="#60a5fa" stroke-width="2" stroke-opacity="0.3" stroke-dasharray="6 4"/>
  <circle cx="160" cy="40" r="28" fill="#38bdf8" opacity="0.18"/>
  <circle cx="35" cy="150" r="20" fill="#93c5fd" opacity="0.12"/>
  <g filter="url(#shadowCowok)">
    <path d="M40 196 C40 160 65 145 100 145 C135 145 160 160 160 196 Z" fill="url(#shirtCowok)"/>
    <path d="M85 145 L100 168 L115 145 Z" fill="#cbd5e1"/>
    <path d="M78 145 L88 172 L100 152 L78 145 Z" fill="#ffffff" stroke="#94a3b8" stroke-width="1"/>
    <path d="M122 145 L112 172 L100 152 L122 145 Z" fill="#ffffff" stroke="#94a3b8" stroke-width="1"/>
    <path d="M96 156 L104 156 L106 188 L100 195 L94 188 Z" fill="#475569"/>
    <rect x="126" y="168" width="16" height="12" rx="2" fill="#cbd5e1" opacity="0.8"/>
    <rect x="129" y="171" width="10" height="6" rx="1" fill="#3b82f6" opacity="0.7"/>
  </g>
  <rect x="88" y="125" width="24" height="24" rx="4" fill="#fb923c" opacity="0.4"/>
  <rect x="88" y="122" width="24" height="20" rx="4" fill="url(#skinCowok)"/>
  <g filter="url(#shadowCowok)">
    <circle cx="62" cy="100" r="10" fill="url(#skinCowok)"/>
    <circle cx="62" cy="100" r="6" fill="#f97316" opacity="0.3"/>
    <circle cx="138" cy="100" r="10" fill="url(#skinCowok)"/>
    <circle cx="138" cy="100" r="6" fill="#f97316" opacity="0.3"/>
    <path d="M66 90 C66 65 80 50 100 50 C120 50 134 65 134 90 C134 116 118 132 100 132 C82 132 66 116 66 90 Z" fill="url(#skinCowok)"/>
    <ellipse cx="78" cy="106" rx="7" ry="4" fill="#f43f5e" opacity="0.25"/>
    <ellipse cx="122" cy="106" rx="7" ry="4" fill="#f43f5e" opacity="0.25"/>
    <path d="M75 80 Q84 76 93 81" stroke="#1e293b" stroke-width="3" stroke-linecap="round" fill="none"/>
    <path d="M107 81 Q116 76 125 80" stroke="#1e293b" stroke-width="3" stroke-linecap="round" fill="none"/>
    <ellipse cx="84" cy="92" rx="5" ry="6" fill="#0f172a"/>
    <circle cx="82" cy="90" r="2" fill="#ffffff"/>
    <circle cx="86" cy="94" r="1" fill="#ffffff"/>
    <ellipse cx="116" cy="92" rx="5" ry="6" fill="#0f172a"/>
    <circle cx="114" cy="90" r="2" fill="#ffffff"/>
    <circle cx="118" cy="94" r="1" fill="#ffffff"/>
    <path d="M99 96 Q100 103 104 102" stroke="#ea580c" stroke-width="1.8" stroke-linecap="round" fill="none" opacity="0.7"/>
    <path d="M88 112 Q100 124 112 112" stroke="#991b1b" stroke-width="2.5" stroke-linecap="round" fill="#ffffff"/>
    <path d="M64 84 C62 65 72 45 92 42 C104 40 122 42 133 50 C140 55 142 66 138 78 C135 73 130 68 124 68 C118 68 114 74 105 70 C96 66 90 70 82 72 C74 74 68 78 64 84 Z" fill="url(#hairCowok)"/>
    <path d="M68 62 Q85 46 112 47" stroke="#64748b" stroke-width="2.5" stroke-linecap="round" fill="none" opacity="0.6"/>
    <path d="M63 80 L67 92 L72 82 Z" fill="#0f172a"/>
    <path d="M137 80 L133 92 L128 82 Z" fill="#0f172a"/>
  </g>
</svg>`;

const AVATAR_CEWEK_NONHIJAB_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
  <defs>
    <linearGradient id="bgCewekNon" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#be185d"/>
      <stop offset="50%" stop-color="#ec4899"/>
      <stop offset="100%" stop-color="#f43f5e"/>
    </linearGradient>
    <linearGradient id="skinCewekNon" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fde2cf"/>
      <stop offset="100%" stop-color="#fed7aa"/>
    </linearGradient>
    <linearGradient id="hairCewekNon" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#374151"/>
      <stop offset="100%" stop-color="#111827"/>
    </linearGradient>
    <linearGradient id="shirtCewekNon" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#f1f5f9"/>
    </linearGradient>
    <filter id="shadowCewekNon" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000" flood-opacity="0.16"/>
    </filter>
  </defs>
  <rect width="200" height="200" rx="44" fill="url(#bgCewekNon)"/>
  <circle cx="100" cy="100" r="88" fill="none" stroke="#fbcfe8" stroke-width="2" stroke-opacity="0.35" stroke-dasharray="6 4"/>
  <circle cx="165" cy="45" r="25" fill="#fda4af" opacity="0.22"/>
  <circle cx="35" cy="155" r="22" fill="#f472b6" opacity="0.16"/>
  <path d="M56 85 C48 115 52 145 62 165 C68 145 68 120 70 100 Z" fill="#111827"/>
  <path d="M144 85 C152 115 148 145 138 165 C132 145 132 120 130 100 Z" fill="#111827"/>
  <circle cx="140" cy="65" r="14" fill="#111827"/>
  <path d="M136 60 Q155 70 148 95 Q140 85 135 70 Z" fill="url(#hairCewekNon)"/>
  <circle cx="138" cy="68" r="5" fill="#ec4899"/>
  <g filter="url(#shadowCewekNon)">
    <path d="M42 196 C42 162 68 148 100 148 C132 148 158 162 158 196 Z" fill="url(#shirtCewekNon)"/>
    <path d="M84 148 L100 166 L116 148 Z" fill="#e2e8f0"/>
    <path d="M78 148 Q88 168 100 152 Q88 148 78 148 Z" fill="#ffffff" stroke="#cbd5e1" stroke-width="1"/>
    <path d="M122 148 Q112 168 100 152 Q112 148 122 148 Z" fill="#ffffff" stroke="#cbd5e1" stroke-width="1"/>
    <path d="M94 154 L106 154 L102 178 L98 178 Z" fill="#475569"/>
    <circle cx="100" cy="156" r="3" fill="#be185d"/>
  </g>
  <rect x="89" y="126" width="22" height="24" rx="4" fill="#f97316" opacity="0.25"/>
  <rect x="89" y="124" width="22" height="20" rx="4" fill="url(#skinCewekNon)"/>
  <g filter="url(#shadowCewekNon)">
    <circle cx="64" cy="102" r="9" fill="url(#skinCewekNon)"/>
    <circle cx="64" cy="102" r="5" fill="#f43f5e" opacity="0.3"/>
    <circle cx="64" cy="106" r="2" fill="#fbcfe8"/>
    <circle cx="136" cy="102" r="9" fill="url(#skinCewekNon)"/>
    <circle cx="136" cy="102" r="5" fill="#f43f5e" opacity="0.3"/>
    <circle cx="136" cy="106" r="2" fill="#fbcfe8"/>
    <path d="M68 92 C68 68 81 52 100 52 C119 52 132 68 132 92 C132 118 116 133 100 133 C84 133 68 118 68 92 Z" fill="url(#skinCewekNon)"/>
    <ellipse cx="78" cy="107" rx="8" ry="5" fill="#fb7185" opacity="0.35"/>
    <ellipse cx="122" cy="107" rx="8" ry="5" fill="#fb7185" opacity="0.35"/>
    <path d="M76 82 Q84 78 92 82" stroke="#1f2937" stroke-width="2.5" stroke-linecap="round" fill="none"/>
    <path d="M108 82 Q116 78 124 82" stroke="#1f2937" stroke-width="2.5" stroke-linecap="round" fill="none"/>
    <ellipse cx="84" cy="93" rx="5.5" ry="6.5" fill="#111827"/>
    <circle cx="82" cy="90" r="2.2" fill="#ffffff"/>
    <circle cx="86.5" cy="95" r="1.2" fill="#ffffff"/>
    <path d="M78 88 Q84 85 89 88" stroke="#111827" stroke-width="1.5" stroke-linecap="round" fill="none"/>
    <path d="M89 87 L92 85" stroke="#111827" stroke-width="1.2" stroke-linecap="round"/>
    <ellipse cx="116" cy="93" rx="5.5" ry="6.5" fill="#111827"/>
    <circle cx="114" cy="90" r="2.2" fill="#ffffff"/>
    <circle cx="118.5" cy="95" r="1.2" fill="#ffffff"/>
    <path d="M111 88 Q116 85 122 88" stroke="#111827" stroke-width="1.5" stroke-linecap="round" fill="none"/>
    <path d="M122 87 L125 85" stroke="#111827" stroke-width="1.2" stroke-linecap="round"/>
    <path d="M99 97 Q100 103 103 103" stroke="#f97316" stroke-width="1.6" stroke-linecap="round" fill="none" opacity="0.6"/>
    <path d="M89 113 Q100 125 111 113" stroke="#be123c" stroke-width="2.5" stroke-linecap="round" fill="#ffffff"/>
    <path d="M64 85 C62 66 73 44 100 44 C127 44 138 66 136 85 C132 75 124 65 112 65 C102 65 98 72 90 68 C82 64 74 72 64 85 Z" fill="url(#hairCewekNon)"/>
    <path d="M72 58 Q95 48 116 52" stroke="#6b7280" stroke-width="2" stroke-linecap="round" fill="none" opacity="0.6"/>
    <rect x="71" y="66" width="12" height="4" rx="2" transform="rotate(-15 71 66)" fill="#fbbf24"/>
    <path d="M66 84 Q68 102 70 106 Q67 100 65 88 Z" fill="#1f2937"/>
    <path d="M134 84 Q132 102 130 106 Q133 100 135 88 Z" fill="#1f2937"/>
  </g>
</svg>`;

const AVATAR_CEWEK_HIJAB_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%">
  <defs>
    <linearGradient id="bgCewekHijab" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f766e"/>
      <stop offset="50%" stop-color="#0d9488"/>
      <stop offset="100%" stop-color="#06b6d4"/>
    </linearGradient>
    <linearGradient id="skinCewekHijab" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#fde2cf"/>
      <stop offset="100%" stop-color="#fed7aa"/>
    </linearGradient>
    <linearGradient id="hijabGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="40%" stop-color="#f8fafc"/>
      <stop offset="100%" stop-color="#e2e8f0"/>
    </linearGradient>
    <linearGradient id="hijabInner" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0f766e"/>
      <stop offset="100%" stop-color="#14b8a6"/>
    </linearGradient>
    <filter id="shadowCewekHijab" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000" flood-opacity="0.16"/>
    </filter>
  </defs>
  <rect width="200" height="200" rx="44" fill="url(#bgCewekHijab)"/>
  <circle cx="100" cy="100" r="88" fill="none" stroke="#99f6e4" stroke-width="2" stroke-opacity="0.35" stroke-dasharray="6 4"/>
  <circle cx="165" cy="40" r="26" fill="#5eead4" opacity="0.22"/>
  <circle cx="35" cy="155" r="22" fill="#2dd4bf" opacity="0.16"/>
  <path d="M42 196 C40 145 52 110 70 85 C90 60 110 60 130 85 C148 110 160 145 158 196 Z" fill="#cbd5e1" opacity="0.7"/>
  <g filter="url(#shadowCewekHijab)">
    <path d="M38 196 C38 152 64 135 100 135 C136 135 162 152 162 196 Z" fill="url(#hijabGrad)"/>
    <path d="M70 160 Q100 185 100 196" stroke="#cbd5e1" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M130 160 Q100 185 100 196" stroke="#cbd5e1" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M85 145 Q100 165 100 180" stroke="#94a3b8" stroke-width="1.5" fill="none" stroke-linecap="round" opacity="0.7"/>
    <circle cx="128" cy="172" r="5" fill="#0d9488"/>
    <circle cx="128" cy="172" r="2" fill="#ffffff"/>
  </g>
  <g filter="url(#shadowCewekHijab)">
    <path d="M58 92 C58 55 74 38 100 38 C126 38 142 55 142 92 C142 124 128 144 100 144 C72 144 58 124 58 92 Z" fill="url(#hijabGrad)"/>
    <path d="M78 68 C86 63 114 63 122 68 C120 62 112 58 100 58 C88 58 80 62 78 68 Z" fill="url(#hijabInner)"/>
    <path d="M72 88 C72 68 84 64 100 64 C116 64 128 68 128 88 C128 114 116 128 100 128 C84 128 72 114 72 88 Z" fill="url(#skinCewekHijab)"/>
    <path d="M72 88 C72 68 84 64 100 64 C116 64 128 68 128 88 C128 76 116 70 100 70 C84 70 72 76 72 88 Z" fill="#94a3b8" opacity="0.25"/>
    <ellipse cx="80" cy="104" rx="7.5" ry="4.5" fill="#f43f5e" opacity="0.28"/>
    <ellipse cx="120" cy="104" rx="7.5" ry="4.5" fill="#f43f5e" opacity="0.28"/>
    <path d="M78 80 Q85 76 93 80" stroke="#1e293b" stroke-width="2.2" stroke-linecap="round" fill="none"/>
    <path d="M107 80 Q115 76 122 80" stroke="#1e293b" stroke-width="2.2" stroke-linecap="round" fill="none"/>
    <ellipse cx="85" cy="91" rx="5.2" ry="6.2" fill="#0f172a"/>
    <circle cx="83.2" cy="88.5" r="2" fill="#ffffff"/>
    <circle cx="87.5" cy="93" r="1.1" fill="#ffffff"/>
    <path d="M79 86 Q85 83 90 86" stroke="#0f172a" stroke-width="1.5" stroke-linecap="round" fill="none"/>
    <path d="M90 85 L93 83" stroke="#0f172a" stroke-width="1.2" stroke-linecap="round"/>
    <ellipse cx="115" cy="91" rx="5.2" ry="6.2" fill="#0f172a"/>
    <circle cx="113.2" cy="88.5" r="2" fill="#ffffff"/>
    <circle cx="117.5" cy="93" r="1.1" fill="#ffffff"/>
    <path d="M110 86 Q115 83 121 86" stroke="#0f172a" stroke-width="1.5" stroke-linecap="round" fill="none"/>
    <path d="M121 85 L124 83" stroke="#0f172a" stroke-width="1.2" stroke-linecap="round"/>
    <path d="M99 95 Q100 101 103 101" stroke="#ea580c" stroke-width="1.5" stroke-linecap="round" fill="none" opacity="0.6"/>
    <path d="M89 110 Q100 122 111 110" stroke="#991b1b" stroke-width="2.5" stroke-linecap="round" fill="#ffffff"/>
    <circle cx="100" cy="133" r="2.5" fill="#0d9488"/>
    <circle cx="100" cy="133" r="1" fill="#ffffff"/>
  </g>
</svg>`;

export const STUDENT_AVATAR_OPTIONS: StudentAvatarOption[] = [
  {
    id: 'siswa-cowok',
    label: 'Siswa Cowok',
    category: 'Pelajar Putra',
    description: 'Siswa laki-laki dengan seragam sekolah rapi dan senyum bersahabat.',
    url: `data:image/svg+xml;utf8,${encodeURIComponent(AVATAR_COWOK_SVG)}`,
  },
  {
    id: 'siswa-cewek-nonhijab',
    label: 'Siswa Cewek Tidak Berjilbab',
    category: 'Pelajar Putri',
    description: 'Siswa perempuan dengan rambut rapi dan ekspresi belajar yang ceria.',
    url: `data:image/svg+xml;utf8,${encodeURIComponent(AVATAR_CEWEK_NONHIJAB_SVG)}`,
  },
  {
    id: 'siswa-cewek-hijab',
    label: 'Siswa Cewek Berjilbab',
    category: 'Pelajar Putri (Berjilbab)',
    description: 'Siswa perempuan dengan jilbab putih sekolah rapi dan santun.',
    url: `data:image/svg+xml;utf8,${encodeURIComponent(AVATAR_CEWEK_HIJAB_SVG)}`,
  },
];
