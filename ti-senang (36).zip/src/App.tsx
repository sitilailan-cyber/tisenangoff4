/**
 * TI SENANG
 * Teknologi Inovatif untuk Sistem Pembelajaran Adaptif dan Menggembirakan
 * MIPA Fase F (Mindful, Meaningful, Joyful)
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { WelcomePage } from './components/welcome/WelcomePage';
import { UserLoginModal } from './components/auth/UserLoginModal';
import { AdminLoginModal } from './components/auth/AdminLoginModal';
import { GuideModal } from './components/common/GuideModal';
import { DeveloperModal } from './components/common/DeveloperModal';
import { WelcomeToast } from './components/common/WelcomeToast';
import { InternetStatusBar } from './components/common/InternetStatusBar';
import { Navbar } from './components/common/Navbar';
import { MuridDashboard } from './components/murid/MuridDashboard';
import { GuruDashboard } from './components/guru/GuruDashboard';
import { AdminCenter } from './components/admin/AdminCenter';
import { UnauthorizedView } from './components/common/UnauthorizedView';
import { soundEffects } from './services/audio/soundEffects';

const AppContent: React.FC = () => {
  const { currentUser, currentRole, logout } = useAuth();

  // Modal Dialog States
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [loginRole, setLoginRole] = useState<'guru' | 'murid'>('murid');
  const [adminLoginModalOpen, setAdminLoginModalOpen] = useState(false);
  const [guideModalOpen, setGuideModalOpen] = useState(false);
  const [developerModalOpen, setDeveloperModalOpen] = useState(false);

  useEffect(() => {
    // Inisialisasi efek suara klik di seluruh tombol aplikasi & suara sambutan
    soundEffects.initGlobalClickListener();
    soundEffects.playWelcomeVoice();
  }, []);

  const handleOpenLogin = (role: 'guru' | 'murid') => {
    setLoginRole(role);
    setLoginModalOpen(true);
  };

  return (
    <div className="min-h-screen w-full flex flex-col font-sans antialiased">
      {/* Offline Alert & Background Sync Banner */}
      <InternetStatusBar />

      {/* Main View Router based on authenticated role */}
      {!currentUser ? (
        <div className="h-screen w-full flex flex-col bg-slate-950 text-slate-100 overflow-hidden">
          <Navbar
            onOpenAdminLogin={() => setAdminLoginModalOpen(true)}
            onOpenGuide={() => setGuideModalOpen(true)}
            onOpenDeveloper={() => setDeveloperModalOpen(true)}
          />
          <div className="flex-1 min-h-0 relative">
            <WelcomePage
              onSelectRoleLogin={handleOpenLogin}
              onOpenAdminLogin={() => setAdminLoginModalOpen(true)}
            />
          </div>
        </div>
      ) : currentRole === 'murid' ? (
        <MuridDashboard user={currentUser} onLogout={logout} />
      ) : currentRole === 'guru' ? (
        <GuruDashboard user={currentUser} onLogout={logout} />
      ) : currentRole === 'admin' ? (
        <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
          <Navbar
            onOpenGuide={() => setGuideModalOpen(true)}
            onOpenDeveloper={() => setDeveloperModalOpen(true)}
          />
          <main className="flex-1">
            <AdminCenter />
          </main>
        </div>
      ) : (
        <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
          <Navbar />
          <UnauthorizedView
            requiredRole="murid"
            onRedirectToOwnDashboard={logout}
          />
        </div>
      )}

      {/* Global Modals */}
      <UserLoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        defaultRole={loginRole}
        onSuccess={() => setLoginModalOpen(false)}
      />

      <AdminLoginModal
        isOpen={adminLoginModalOpen}
        onClose={() => setAdminLoginModalOpen(false)}
        onSuccess={() => setAdminLoginModalOpen(false)}
      />

      <GuideModal
        isOpen={guideModalOpen}
        onClose={() => setGuideModalOpen(false)}
      />

      <DeveloperModal
        isOpen={developerModalOpen}
        onClose={() => setDeveloperModalOpen(false)}
      />

      {/* Personalized Welcome Toast */}
      <WelcomeToast user={currentUser} />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
